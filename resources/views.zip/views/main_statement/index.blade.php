@extends('layout.app')

@section('title', 'كشف الحساب الرئيسي')

@section('content')
<div class="main-content app-content">
    <div class="container-fluid">

        @include('partials.crumb')

        <!-- Start:: row-1 -->
        <div class="row">
            <div class="col-xl-12">
                <div class="card custom-card">
                    <div class="card-header justify-content-between">
                        <div class="card-title">
                            كشف الحساب الرئيسي
                        </div>
                        <div class="card-options w-100">
                            <div class="row w-100">
                                <div class="col-md-12 mb-3 mb-md-0 d-flex justify-content-end">
                                    <!-- زر إضافة رأس مال منفصل -->
                                    <button class="btn btn-warning d-flex align-items-center px-4 py-2" style="border-radius: 8px; font-size: 1.1rem;" data-bs-toggle="modal" data-bs-target="#addCapitalModal">
                                        <i class="fa fa-plus me-2"></i>
                                        إضافة رأس مال
                                    </button>
                                </div>
                                <div class="col-md-3 mb-3 mb-md-0">
                                    <button class="btn btn-primary-light w-100 summary-item py-3 px-2" style="border-radius: 8px; text-align: right;">
                                        <div class="mb-1" style="font-size: 1rem; color: #6c757d;">إجمالي الدائن</div>
                                        <div style="font-size: 1.15rem; color: #007bff; font-weight: 700;">
                                            {{ number_format($total_income, 2) }} جنيه
                                        </div>
                                    </button>
                                </div>
                                <div class="col-md-3 mb-3 mb-md-0">
                                    <button class="btn btn-danger-light w-100 summary-item py-3 px-2" style="border-radius: 8px; text-align: right;">
                                        <div class="mb-1" style="font-size: 1rem; color: #6c757d;">إجمالي المدين</div>
                                        <div style="font-size: 1.15rem; color: #dc3545; font-weight: 700;">
                                            {{ number_format($total_expense, 2) }} جنيه
                                        </div>
                                    </button>
                                </div>
                                <div class="col-md-3 mb-3 mb-md-0">
                                    <button class="btn btn-success-light w-100 summary-item py-3 px-2" style="border-radius: 8px; text-align: right;">
                                        <div class="mb-1" style="font-size: 1rem; color: #6c757d;">الرصيد الحالي</div>
                                        <div style="font-size: 1.15rem; color: #28a745; font-weight: 700;">
                                            {{ number_format($balance, 2) }} جنيه
                                        </div>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Modal لإضافة رأس مال -->
                    <div class="modal fade" id="addCapitalModal" tabindex="-1" aria-labelledby="addCapitalModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <form method="POST" action="{{ route('main-statement.addCapital') }}">
                                @csrf
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="addCapitalModalLabel">إضافة رأس مال</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="إغلاق"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="mb-3">
                                            <label for="capitalAmount" class="form-label">المبلغ</label>
                                            <input type="number" step="0.01" min="0" class="form-control" id="capitalAmount" name="amount" required>
                                        </div>
                                        <div class="mb-3">
                                            <label for="capitalDescription" class="form-label">البيان (اختياري)</label>
                                            <input type="text" class="form-control" id="capitalDescription" name="description">
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-warning">إضافة</button>
                                     <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>

                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table text-nowrap table-bordered border-primary">
                                <thead>
                                    <tr>
                                        <th>م</th>
                                        <th>التاريخ</th>
                                        <th>البيان</th>
                                        <th>دائن</th>
                                        <th>مدين</th>
                                        <th>الرصيد</th>
                                    </tr>
                                </thead>
                                <tbody>


@foreach ($transactions as $index => $txn)
    <tr>
        <td>{{ $loop->iteration }}</td>
        <td>{{ \Carbon\Carbon::parse($txn->created_at)->format('Y-m-d h:i A') }}</td>
        <td>{{ $txn->description ?? ($txn->type === 'credit' ? 'دخل' : 'مصروف') }}</td>
        <td>{{ number_format($txn->type === 'credit' ? $txn->amount : 0, 2) }}</td>
        <td>{{ number_format($txn->type === 'debit' ? $txn->amount : 0, 2) }}</td>
        <td>{{ number_format($txn->running_balance, 2) }}</td>
    </tr>
@endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- End:: row-1 -->

    </div>
</div>
@endsection
