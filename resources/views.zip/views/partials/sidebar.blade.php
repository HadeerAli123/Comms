<style>
.header-logo img {
  max-height: 85px !important;
  max-width: 180px !important;
  display: block !important;
  margin: 0 auto !important;
  object-fit: contain !important;
}
.app-sidebar .main-sidebar-header .header-logo img {
  height: 9.5rem !important;
}
.side-menu__icon {
  color: #007bff !important;
  transition: color 0.3s ease-in-out;
}
.slide:nth-child(2) .side-menu__icon { color: #ff00ea !important; }
.slide:nth-child(3) .side-menu__icon { color: #fd7e14 !important; }
.slide:nth-child(4) .side-menu__icon { color: #ffc107 !important; }
.slide:nth-child(5) .side-menu__icon { color: #20c997 !important; }
.slide:nth-child(6) .side-menu__icon { color: #9bc1427c !important; }
.side-menu__label, .breadcrumb-item {
  font-size: 1.1rem !important;
  font-weight: 500 !important;
  color: rgba(26, 24, 24, 0.562) !important;
}

</style>

<aside class="app-sidebar sticky" id="sidebar">
  <!-- Logo -->
  <div class="main-sidebar-header">
    <a href="{{ route('dashboard') }}" class="header-logo">
      <img src="{{ asset('assets/images/new-logos/logo.png') }}" alt="logo" class="desktop-logo">
    </a>
  </div>

  <!-- Menu -->
  <div class="main-sidebar" id="sidebar-scroll">
    <nav class="main-menu-container nav nav-pills flex-column sub-open">
           <ul class="main-menu list-unstyled">
        <li class="slide mb-2">
          <a href="{{ route('dashboard') }}" class="side-menu__item d-flex align-items-center gap-2">
            <i class="bi bi-house side-menu__icon"></i>
            <span class="side-menu__label">الرئيسية</span>
          </a>
        </li>
        <li class="slide mb-2">
          <a href="{{ route('sites.index') }}" class="side-menu__item d-flex align-items-center gap-2">
            <i class="bi bi-geo-alt side-menu__icon"></i>
            <span class="side-menu__label">مواقع التسويق</span>
          </a>
        </li>
        <li class="slide mb-2">
          <a href="{{ route('marketers.index') }}" class="side-menu__item d-flex align-items-center gap-2">
            <i class="bi bi-person-plus side-menu__icon"></i>
            <span class="side-menu__label">المسوقين</span>
          </a>
        </li>
        <li class="slide mb-2">
          <a href="{{ route('influencers.index') }}" class="side-menu__item d-flex align-items-center gap-2">
            <i class="bi bi-file-earmark-text side-menu__icon"></i>
            <span class="side-menu__label">مشاهير الاعلانات</span>
          </a>
        </li>
        <li class="slide mb-2">
          <a href="{{ route('visits.index') }}" class="side-menu__item d-flex align-items-center gap-2">
            <i class="bi bi-eye side-menu__icon"></i>
            <span class="side-menu__label">زيارات المشاهير</span>
          </a>
        </li>
        <li class="slide mb-2">
          <a href="{{ route('commissions.client_visits') }}" class="side-menu__item d-flex align-items-center gap-2">
            <i class="bi bi-eye side-menu__icon"></i>
            <span class="side-menu__label">زيارات العملاء</span>
          </a>
        </li>
        <li class="slide mb-2">
          <a href="{{ route('commissions.index') }}" class="side-menu__item d-flex align-items-center gap-2">
            <i class="bi bi-calculator side-menu__icon"></i>
            <span class="side-menu__label">عمولات</span>
          </a>
        </li>
        <li class="slide mb-2">
          <a href="{{ route('marketing-employees.index') }}" class="side-menu__item d-flex align-items-center gap-2">
            <i class="bi bi-people side-menu__icon"></i>
            <span class="side-menu__label">موظفين التسويق</span>
          </a>
        </li>
        <li class="slide mb-2">
          <a href="{{ route('main-statement.index') }}" class="side-menu__item d-flex align-items-center gap-2">
            <i class="bi bi-file-earmark-text side-menu__icon"></i>
            <span class="side-menu__label">كشف حساب رئيسي</span>
          </a>
        </li>
      </ul>
    </nav>
  </div>
</aside>
