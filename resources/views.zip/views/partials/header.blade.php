<header class="app-header sticky" id="header">
  <div class="main-header-container container-fluid d-flex justify-content-between align-items-center">
    <!-- زر القائمة (يظهر فقط على الموبايل) -->
    <button class="btn btn-primary d-md-none" id="toggleSidebar">
      ☰ القائمة
    </button>

    <!-- البروفايل -->
    @include('partials.profile')
  </div>
</header>

<!-- أضف عنصر الـ sidebar هنا -->
<aside class="sidebar" id="sidebar">
    <!-- Logo -->


    <!-- Menu -->
    <div class="main-sidebar" id="sidebar-scroll">
        <nav class="main-menu-container nav nav-pills flex-column sub-open">
            <ul class="main-menu list-unstyled">
                  <a href="{{ route('dashboard') }}" class="header-logo" style="display: inline-block;">
            <img src="{{ asset('assets/images/new-logos/logo.png') }}" alt="logo" class="desktop-logo" style="max-width: 140px;">
        </a>
                <li class="slide mb-2">
                    <a href="{{ route('dashboard') }}" class="side-menu__item d-flex align-items-center gap-2">
                        <i class="bi bi-house side-menu__icon"></i>
                        <span class="side-menu__label">الرئيسية</span>
                    </a>
                </li>
                <li class="slide mb-2">
                    <a href="{{ route('sites.index') }}" class="side-menu__item d-flex align-items-center gap-2">
                        <i class="bi bi-geo-alt side-menu__icon"></i>
                        <span class="side-menu__label">مواقع التسويق</span>
                    </a>
                </li>
                <li class="slide mb-2">
                    <a href="{{ route('marketers.index') }}" class="side-menu__item d-flex align-items-center gap-2">
                        <i class="bi bi-person-plus side-menu__icon"></i>
                        <span class="side-menu__label">المسوقين</span>
                    </a>
                </li>
                <li class="slide mb-2">
                    <a href="{{ route('influencers.index') }}" class="side-menu__item d-flex align-items-center gap-2">
                        <i class="bi bi-file-earmark-text side-menu__icon"></i>
                        <span class="side-menu__label">مشاهير الاعلانات</span>
                    </a>
                </li>
                <li class="slide mb-2">
                    <a href="{{ route('visits.index') }}" class="side-menu__item d-flex align-items-center gap-2">
                        <i class="bi bi-eye side-menu__icon"></i>
                        <span class="side-menu__label">زيارات المشاهير</span>
                    </a>
                </li>
                <li class="slide mb-2">
                    <a href="{{ route('commissions.client_visits') }}" class="side-menu__item d-flex align-items-center gap-2">
                        <i class="bi bi-eye side-menu__icon"></i>
                        <span class="side-menu__label">زيارات العملاء</span>
                    </a>
                </li>
                <li class="slide mb-2">
                    <a href="{{ route('commissions.index') }}" class="side-menu__item d-flex align-items-center gap-2">
                        <i class="bi bi-calculator side-menu__icon"></i>
                        <span class="side-menu__label">عمولات</span>
                    </a>
                </li>
                <li class="slide mb-2">
                    <a href="{{ route('marketing-employees.index') }}" class="side-menu__item d-flex align-items-center gap-2">
                        <i class="bi bi-people side-menu__icon"></i>
                        <span class="side-menu__label">موظفين التسويق</span>
                    </a>
                </li>
                <li class="slide mb-2">
                    <a href="{{ route('main-statement.index') }}" class="side-menu__item d-flex align-items-center gap-2">
                        <i class="bi bi-file-earmark-text side-menu__icon"></i>
                        <span class="side-menu__label">كشف حساب رئيسي</span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</aside>
<style>
.sidebar {
    position: fixed;
    top: 0;
    right: -250px;
    width: 250px;
    height: 100%;
    background: #fff;
    box-shadow: -2px 0 8px rgba(0,0,0,0.1);
    transition: right 0.3s;
    z-index: 1050;
}
.sidebar.active {
    right: 0;
}
.sidebar-backdrop {
    display: none;
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0,0,0,0.3);
    z-index: 1049;
}
.sidebar-backdrop.active {
    display: block;
}

/* تحريك عناصر القائمة شمال بإضافة بادينج من اليمين */
.main-menu .side-menu__item {
    padding-right: 16px;
}
</style>

<script>
document.addEventListener("DOMContentLoaded", function () {
  const toggleBtn = document.getElementById("toggleSidebar");
  const sidebar = document.getElementById("sidebar");

  let backdrop = document.createElement("div");
  backdrop.className = "sidebar-backdrop";
  document.body.appendChild(backdrop);

  toggleBtn.addEventListener("click", function () {
    sidebar.classList.toggle("active");
    backdrop.classList.toggle("active");
  });

  backdrop.addEventListener("click", function () {
    sidebar.classList.remove("active");
    backdrop.classList.remove("active");
  });
});
</script>
