<ul class="header-content-right">

    <!-- ... -->
    <li class="header-element notifications-dropdown d-xl-block d-none dropdown">
        <!-- ... -->
        <div class="main-header-dropdown dropdown-menu dropdown-menu-end" data-popper-placement="none">
            <!-- ... -->
            <div class="tab-content">
                <div class="tab-pane show active p-0 border-0" id="activity-tab-pane" role="tabpanel"
                    aria-labelledby="activity-tab" tabindex="0">
                    <ul class="list-unstyled mb-0" id="header-notification-scroll1">
                        <li class="dropdown-item">
                            <div class="d-flex align-items-start">
                                <div class="pe-2 lh-1"> <span
                                        class="avatar avatar-md avatar-rounded svg-white">
                                        <img src="{{ asset('assets/images/faces/2.jpg') }}" alt="img"> </span>
                                </div>
                                <!-- ... -->
                            </div>
                        </li>
                        <li class="dropdown-item">
                            <div class="d-flex align-items-start">
                                <div class="pe-2 lh-1"> <span
                                        class="avatar avatar-md avatar-rounded svg-white">
                                        <img src="{{ asset('assets/images/faces/6.jpg') }}" alt="img"> </span>
                                </div>
                                <!-- ... -->
                            </div>
                        </li>
                        <li class="dropdown-item">
                            <div class="d-flex align-items-start">
                                <div class="pe-2 lh-1"> <span
                                        class="avatar avatar-md avatar-rounded svg-white">
                                        <img src="{{ asset('assets/images/faces/14.jpg') }}" alt="img"> </span>
                                </div>
                                <!-- ... -->
                            </div>
                        </li>
                        <!-- ... -->
                    </ul>
                </div>
                <!-- ... -->
            </div>
            <!-- ... -->
        </div>
        <!-- ... -->
    </li>
    <!-- ... -->
    <li class="header-element dropdown">
        <!-- ... -->
        <a href="javascript:void(0);" class="header-link dropdown-toggle" id="mainHeaderProfile"
            data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false">
            <div class="d-flex align-items-center">
            <div class="me-xl-2 me-0">
                <img src="{{ asset('assets/images/faces/2.jpg') }}" alt="img" class="avatar avatar-sm avatar-rounded">
            </div>
            <div class="d-xl-block d-none lh-1">
                <span class="fw-medium lh-1">Mr. Jack</span>
            </div>
            </div>
        </a>
        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="mainHeaderProfile">
            <li>
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit" class="dropdown-item">تسجيل الخروج</button>
            </form>
            </li>
        </ul>
        <!-- ... -->
    </li>
    <!-- ... -->
</ul>
