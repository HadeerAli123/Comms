<!-- Tabs داخلية -->

<ul class="nav nav-pills mb-3" id="subTabs-{{ $type }}" role="tablist">
    <li class="nav-item col-md-3" role="presentation">
        <button class="nav-link active rounded-pill px-4 py-2 fw-bold w-100 border border-primary" id="sub-{{ $type }}-all" data-bs-toggle="tab" data-bs-target="#sub-{{ $type }}-all-pane" type="button" role="tab" aria-controls="sub-{{ $type }}-all-pane" aria-selected="true">
            الكل ({{ $commissions->count() }})
        </button>
    </li>
    <li class="nav-item col-md-3" role="presentation">
        <button class="nav-link rounded-pill px-4 py-2 fw-bold w-100 border border-primary" id="sub-{{ $type }}-delivered" data-bs-toggle="tab" data-bs-target="#sub-{{ $type }}-delivered-pane" type="button" role="tab" aria-controls="sub-{{ $type }}-delivered-pane" aria-selected="false">
            تم التسليم ({{ $commissions->where('received', 1)->count() }})
        </button>
    </li>
    <li class="nav-item col-md-3" role="presentation">
        <button class="nav-link rounded-pill px-4 py-2 fw-bold w-100 border border-primary" id="sub-{{ $type }}-pending" data-bs-toggle="tab" data-bs-target="#sub-{{ $type }}-pending-pane" type="button" role="tab" aria-controls="sub-{{ $type }}-pending-pane" aria-selected="false">
            لم يتم التسليم ({{ $commissions->where('received', 0)->count() }})
        </button>
    </li>
</ul>

<div class="tab-content" id="subTabsContent-{{ $type }}">
    <!-- الكل -->
    <div class="tab-pane fade show active" id="sub-{{ $type }}-all-pane" role="tabpanel">
        @include('commissions.partials.table', ['commissions' => $commissions])
    </div>

    <!-- تم التسليم -->
    <div class="tab-pane fade" id="sub-{{ $type }}-delivered-pane" role="tabpanel">
        @include('commissions.partials.table', ['commissions' => $commissions->where('received', 1)])
    </div>

    <!-- لم يتم التسليم -->
    <div class="tab-pane fade" id="sub-{{ $type }}-pending-pane" role="tabpanel">
        @include('commissions.partials.table', ['commissions' => $commissions->where('received', 0)])
    </div>
</div>
