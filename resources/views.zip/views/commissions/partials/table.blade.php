                            <div class="table-responsive">

<table class="table table-bordered text-nowrap">
    <thead>
        <tr>
            <th>م</th>
            <th>الموقع</th>
            <th>المسوّق / الموظف</th>
            <th>الرقم التسويقي</th>
            <th>عدد الزوار</th>
            <th>عدد الأطباق</th>
            <th>مبلغ العمولة</th>
            <th>مبلغ الفاتورة</th>
                @if($type === 'all')
                <th>نوع الزيارة</th>
            @endif

            {{-- لو التاب الفرعي = الكل → اعرض عمود الحالة --}}
            @if($subTab === 'all')
                <th>الحالة</th>
            @endif
            <th>اسم المستخدم</th>
            <th>تاريخ الإضافة</th>
            @if($subTab === 'all' || $subTab === 'pending')

          <th> تسليم العمولة</th>


@endif
        </tr>
    </thead>
    <tbody>
        @forelse($commissions as $commission)
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $commission->site?->name ?? '—' }}</td>
    <td>
        {{ $commission->marketer?->name ?? $commission->marketingEmployee?->name ?? '—' }}
        <br>
        <small class="text-muted">
            {{ $commission->marketer?->phone ?? $commission->marketingEmployee?->phone ?? '—' }}
        </small>
    </td>
    <td>
        {{ $commission->marketer?->marketing_code ?? $commission->marketingEmployee?->marketing_code ?? '—' }}
    </td>

                <td>{{ $commission->visitors }}</td>
                <td>{{ $commission->dishes }}</td>
                <td>{{ $commission->commission_amount }}</td>
                <td>{{ $commission->invoice_amount }}</td>
                   {{-- نوع الزيارة --}}
                @if($type === 'all')
                    <td>
                        {{ $commission->marketer_id ? 'مسوّق' : 'موظف' }}
                    </td>
                @endif

                {{-- الحالة --}}
                @if($subTab === 'all')
                    <td>
                        @if($commission->received == 1)
                            <span class="badge bg-success">تم التسليم</span>
                        @else
                            <span class="badge bg-warning text-dark">لم يتم التسليم</span>
                        @endif
                    </td>
                @endif
                <td>{{ $commission->creator?->name ?? '—' }}</td>
                <td>{{ $commission->created_at->format('Y-m-d') }}</td>
                @if($subTab === 'all' || $subTab === 'pending')
    <td>
        @if($commission->received != 1)
            <form action="{{ route('commissions.deliverRequest', $commission->id) }}" method="POST">
                @csrf
                <button type="submit" class="btn btn-sm btn-success">
                    <i class="ri-whatsapp-line"></i> تسليم
                </button>
            </form>
        @else
            <span class="badge bg-secondary">تم التسليم</span>
        @endif
    </td>
@endif
            </tr>
        @empty
            <tr>
                <td colspan="9" class="text-center">لا توجد بيانات</td>
            </tr>
        @endforelse
    </tbody>
</table>
                            </div>
