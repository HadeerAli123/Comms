@extends('layout.app')

@section('title', 'العمولات')

@section('content')
<div class="main-content app-content">
    <div class="container-fluid">
        @include('partials.crumb')
   <div class="row">
                <div class="col-xl-12">
        <div class="card custom-card">
           <div class="card-header">
                <div class="card-title">العمولات</div>
                <div class="row w-100">
                    <br/><br/>
                    <div class="col-md-4">
                        <form method="GET" action="{{ route('commissions.index') }}" class="d-flex align-items-center gap-2">
                            <input type="text" name="search" class="form-control" placeholder="بحث بالاسم أو رقم الهاتف أو الرقم التسويقي" value="{{ request('search') }}" style="max-width: 300px;">
                            <button type="submit" class="btn btn-primary">بحث</button>
                        </form>
                    </div>

                    <div class="col-md-4">
                        <!-- يمكنك إضافة أي عنصر آخر هنا أو تركه فارغاً -->
                    </div>
                    <div class="col-md-4">
                        <form method="GET" action="{{ route('commissions.index') }}">
                            <div class="geex-content__form__single">
                                <label for="filter-date" class="input-label">اختر التاريخ</label>
                                <div class="geex-content__form__single__box">
                                    <div class="input-wrapper input-icon">
                                        <input type="date"
                                            id="filter-date"
                                            name="created_at"
                                            class="form-control"
                                            value="{{ request('created_at') }}"
                                            onchange="this.form.submit()" />
                                        <i class="uil uil-calendar-alt" style="display: none;"></i>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

            </div>


            <div class="card-body">

                <!-- Tabs رئيسية -->
                <ul class="nav nav-pills mb-3" id="mainTabs" role="tablist">
                    <li class="nav-item col-md-3" role="presentation">
                        <button class="nav-link active rounded-pill px-4 py-2 fw-bold w-100 border border-primary" id="all-tab" data-bs-toggle="pill" data-bs-target="#allTab" type="button" role="tab" aria-controls="allTab" aria-selected="true">
                            الكل ({{ $commissions->count() }})
                        </button>
                    </li>
                    <li class="nav-item col-md-3" role="presentation">
                        <button class="nav-link rounded-pill px-4 py-2 fw-bold w-100 border border-primary" id="marketers-tab" data-bs-toggle="pill" data-bs-target="#marketersTab" type="button" role="tab" aria-controls="marketersTab" aria-selected="false">
                            عمولات مسوّقين ({{ $commissions->whereNotNull('marketer_id')->count() }})
                        </button>
                    </li>
                    <li class="nav-item col-md-3" role="presentation">
                        <button class="nav-link rounded-pill px-4 py-2 fw-bold w-100 border border-primary" id="employees-tab" data-bs-toggle="pill" data-bs-target="#employeesTab" type="button" role="tab" aria-controls="employeesTab" aria-selected="false">
                            عمولات موظفين ({{ $commissions->whereNotNull('employee_id')->count() }})
                        </button>
                    </li>
                </ul>

                <div class="tab-content" id="mainTabsContent">

                    <!-- Tab الكل -->
                    <div class="tab-pane fade show active" id="allTab" role="tabpanel">
                        @include('commissions.partials.subtabs', [
                            'type' => 'all',
                            'commissions' => $commissions
                        ])
                    </div>

                    <!-- Tab المسوقين -->
                    <div class="tab-pane fade" id="marketersTab" role="tabpanel">
                        @include('commissions.partials.subtabs', [
                            'type' => 'marketer',
                            'commissions' => $commissions->whereNotNull('marketer_id')
                        ])
                    </div>

                    <!-- Tab الموظفين -->
                    <div class="tab-pane fade" id="employeesTab" role="tabpanel">
                        @include('commissions.partials.subtabs', [
                            'type' => 'employee',
                            'commissions' => $commissions->whereNotNull('employee_id')
                        ])
                    </div>

                </div>
            </div>
        </div>
                </div></div>
    </div>
</div>
@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
@endpush
