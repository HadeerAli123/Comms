@extends('layout.app')

@section('title', 'المسوقين')
<style>
.breadcrumb .breadcrumb-item {
    display: flex;
    align-items: center;
}

.breadcrumb .breadcrumb-item + .breadcrumb-item::before {
    content: "»";
    padding: 0 0.5rem;
    color: #999;
    display: inline-block;
}
</style>
@section('content')
    <!-- Start::app-content -->
    <div class="main-content app-content">
        <div class="container-fluid">

            @include('partials.crumb')


            <!-- Start:: row-1 -->
            <div class="row">
                <div class="col-xl-12">
                    <div class="card custom-card">
                        <div class="card-header justify-content-between">
                            <div class="card-title">
                                تسليم العمولة
                            </div>

                        </div>


                        <div class="card-body">
                         <form action="{{ route('commissions.deliverStore', $commission->id) }}" method="POST">
    @csrf
    <div class="mb-3">
        <label class="form-label">الكود المستلم</label>
        <input type="text" name="delivery_code" class="form-control" required>
    </div>
    <div class="mb-3">
        <label class="form-label">المبلغ المُسلّم</label>
        <input type="number" name="delivered_amount" class="form-control" step="0.01" value="{{ $commission->commission_amount }}" readonly>
    </div>
    <button type="submit" class="btn btn-primary">تأكيد</button>
</form>
                        </div>

                    </div>
                </div>
            </div>
            <!-- End:: row-1 -->



        </div>
    </div>
    <!-- End::app-content -->

@endsection
