@extends('layout.app')

@section('title', 'زيارات العملاء')

@section('content')
    <!-- Start::app-content -->
    <div class="main-content app-content">
        <div class="container-fluid">

            @include('partials.crumb')


            <!-- Start:: row-1 -->
            <div class="row">
                <div class="col-xl-12">
                    <div class="card custom-card">
                        <div class="card-header justify-content-between">
                            <div class="card-title">
                                زيارات العملاء
                            </div>
<div class="d-flex justify-content-end align-items-center w-100">
    <div>
        <button class="btn btn-primary btn-sm btn-wave" data-bs-toggle="modal" data-bs-target="#addSiteModal">
            <i class="ri-add-line me-1 fw-medium align-middle"></i> إضافة زيارة جديدة
        </button>
    </div>
    <div class="d-flex flex-wrap gap-2 ms-2">
        <form method="GET" action="{{ route('commissions.index') }}">
            <div class="row mb-3 justify-content-end">
                <div class="col-md-12">
                    <div class="geex-content__form__single">
                        <label for="filter-date" class="input-label">اختر التاريخ</label>
                        <div class="geex-content__form__single__box">
                            <div class="input-wrapper input-icon">
                                <input type="date" id="filter-date" name="created_at" class="form-control" value="{{ request('created_at') }}" onchange="this.form.submit()" />
                                <i class="uil uil-calendar-alt" style="display: none;"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="modal fade" id="addSiteModal" tabindex="-1" aria-labelledby="addSiteModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
<form action="{{ route('commissions.store') }}" method="POST" class="geex-content__form" enctype="multipart/form-data">
    @csrf
<div class="modal-header">
                                <h6 class="modal-title">إضافة زيارة جديدة</h6>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>

    <div class="modal-body">
        <div class="geex-content__form__wrapper">
            <div class="geex-content__form__wrapper__item geex-content__form__right">

                <div class="geex-content__form__single mb-4">
                    <label class="input-label mb-2">اختر نوع الشخص</label>
                    <div class="d-flex gap-4 align-items-center ps-3">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" id="type_marketer" name="person_type" value="marketer">
                            <label class="form-check-label" for="type_marketer">مسوق</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" id="type_employee" name="person_type" value="employee">
                            <label class="form-check-label" for="type_employee">موظف</label>
                        </div>
                    </div>
                </div>

                <div id="marketer-input-box" class="geex-content__form__single" style="display:none;">
                    <label for="marketer_code" class="input-label">الرقم التسويقي للمسوق</label>
                    <br/><br/>
                    <div class="geex-content__form__single__box">
                        <div class="input-wrapper">
                            <input id="marketer_code" name="marketer_code" placeholder="أدخل الرقم التسويقي للمسوق" class="form-control" />
                        </div>
                    </div>
                </div>

                <div id="employee-input-box" class="geex-content__form__single" style="display:none;">
                    <label for="employee_code" class="input-label">الرقم التسويقي للموظف</label>
                    <br/><br/>
                    <div class="geex-content__form__single__box">
                        <div class="input-wrapper">
                            <input id="employee_code" name="employee_code" placeholder="أدخل الرقم التسويقي للموظف" class="form-control" />
                        </div>
                    </div>
                </div>

                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        const marketerRadio = document.getElementById('type_marketer');
                        const employeeRadio = document.getElementById('type_employee');
                        const marketerBox = document.getElementById('marketer-input-box');
                        const employeeBox = document.getElementById('employee-input-box');
                        const marketerInput = document.getElementById('marketer_code');
                        const employeeInput = document.getElementById('employee_code');
                        const detailsDiv = document.getElementById('marketer-details');
                        const extraFields = document.getElementById('extra-fields');

                        function showMarketer() {
                            marketerBox.style.display = '';
                            marketerInput.required = true;
                            employeeBox.style.display = 'none';
                            employeeInput.required = false;
                            detailsDiv.style.display = 'none';
                            detailsDiv.innerHTML = '';
                            extraFields.style.display = 'none';
                        }

                        function showEmployee() {
                            marketerBox.style.display = 'none';
                            marketerInput.required = false;
                            employeeBox.style.display = '';
                            employeeInput.required = true;
                            detailsDiv.style.display = 'none';
                            detailsDiv.innerHTML = '';
                            extraFields.style.display = 'none';
                        }

                        marketerRadio.addEventListener('change', function() {
                            if (this.checked) showMarketer();
                        });
                        employeeRadio.addEventListener('change', function() {
                            if (this.checked) showEmployee();
                        });

                        // Marketer search
                        marketerInput.addEventListener('input', function() {
                            if (!marketerRadio.checked) return;
                            const code = this.value.trim();
                            if (!code) {
                                detailsDiv.style.display = 'none';
                                detailsDiv.innerHTML = '';
                                extraFields.style.display = 'none';
                                return;
                            }
                            fetch("{{ url('marketers/details') }}/" + code)
                                .then(resp => {
                                    if (!resp.ok) throw new Error("Marketer not found");
                                    return resp.json();
                                })
                                .then(data => {
                                    detailsDiv.innerHTML = `
                                        <div class="alert alert-info">
                                            <strong>اسم المسوق:</strong> ${data.name}<br>
                                            <strong>رقم الهاتف:</strong> ${data.phone}<br>
                                            <strong>كود التسويق:</strong> ${data.marketing_code}<br>
                                            <strong>الموقع:</strong> ${data.site ? data.site : 'غير محدد'}<br>
                                            <strong>الموظف:</strong> ${data.employee ? data.employee : 'غير محدد'}<br>
                                        </div>
                                    `;
                                    detailsDiv.style.display = 'block';
                                    extraFields.style.display = 'block';
                                })
                                .catch(err => {
                                    detailsDiv.innerHTML = '<div class="alert alert-danger">لم يتم العثور على تفاصيل المسوق.</div>';
                                    detailsDiv.style.display = 'block';
                                    extraFields.style.display = 'none';
                                });
                        });

                        // Employee search
                        employeeInput.addEventListener('input', function() {
                            if (!employeeRadio.checked) return;
                            const code = this.value.trim();
                            if (!code) {
                                detailsDiv.style.display = 'none';
                                detailsDiv.innerHTML = '';
                                extraFields.style.display = 'none';
                                return;
                            }
                            fetch("{{ url('users/details') }}/" + code)
                                .then(resp => {
                                    if (!resp.ok) throw new Error("Employee not found");
                                    return resp.json();
                                })
                                .then(data => {
                                    detailsDiv.innerHTML = `
                                        <div class="alert alert-info">
                                            <strong>اسم الموظف:</strong> ${data.name}<br>
                                            <strong>رقم الهاتف:</strong> ${data.phone}<br>
                                            <strong>الرقم التسويقي:</strong> ${data.marketing_code}<br>
                                            <strong>القسم:</strong> ${data.department ? data.department : 'غير محدد'}<br>
                                        </div>
                                    `;
                                    detailsDiv.style.display = 'block';
                                    extraFields.style.display = 'block';
                                })
                                .catch(err => {
                                    detailsDiv.innerHTML = '<div class="alert alert-danger">لم يتم العثور على تفاصيل الموظف.</div>';
                                    detailsDiv.style.display = 'block';
                                    extraFields.style.display = 'none';
                                });
                        });
                    });
                </script>
        <div id="marketer-details" style="margin-top:10px; display:none;"></div>

<br/><br/>
<div id="extra-fields" style="display:none;">
    <div class="geex-content__form__single__box">
        <div class="row mb-2" id="employee-fields" style="display:none;">
            <div class="col-md-4">
                <div class="input-wrapper input-icon">
                    <label for="visitors_count" class="input-label">عدد الأشخاص</label>
                    <input
                        id="visitors_count"
                        name="visitors_count_employee"
                        type="number"
                        min="0"
                        step="1"
                        placeholder="أدخل عدد الأشخاص"
                        class="form-control"
                        required
                    >
                    <i class="uil bi-person"></i>
                </div>
            </div>
            <div class="col-md-4">
                <div class="input-wrapper input-icon">
                    <label for="cheque_amount" class="input-label">مبلغ الشيك</label>
                    <input
                        id="cheque_amount"
                        name="cheque_amount"
                        type="number"
                        min="0"
                        step="0.01"
                        placeholder="أدخل مبلغ الشيك"
                        class="form-control"
                        required
                    >
                    <i class="uil uil-money-bill"></i>
                </div>
            </div>
            <div class="col-md-4">
                <div class="input-wrapper input-icon">
                    <label for="invoice_amount" class="input-label">مبلغ الفاتورة</label>
                    <input
                        id="invoice_amount"
                        name="invoice_amount"
                        type="number"
                        min="0"
                        step="0.01"
                        placeholder="أدخل مبلغ الفاتورة"
                        class="form-control"
                        required
                    >
                    <i class="uil uil-receipt"></i>
                </div>
            </div>
            <div class="col-md-4 mt-2">
                <div class="input-wrapper input-icon">
                    <label for="dishes_count" class="input-label">عدد الأطباق</label>
                    <input
                        id="dishes_count"
                        name="dishes_count"
                        type="number"
                        min="0"
                        step="1"
                        placeholder="أدخل عدد الأطباق"
                        class="form-control"
                        required
                    >
                    <i class="uil uil-restaurant"></i>
                </div>
            </div>
            <div class="col-md-4 mt-2">
                <div class="input-wrapper input-icon">
                    <label for="discount_rate" class="input-label">نسبة الخصم (إن وجدت)</label>
                    <input
                        id="discount_rate"
                        name="discount_rate"
                        type="number"
                        min="0"
                        max="100"
                        step="0.01"
                        placeholder="أدخل نسبة الخصم"
                        class="form-control"
                    >
                    <i class="uil uil-percentage"></i>
                </div>
            </div>
            <div class="col-md-4 mt-2">
                <div class="input-wrapper input-icon">
                    <label for="commission_amount_employee" class="input-label">مبلغ العمولة</label>
                    <input
                        id="commission_amount_employee"
                        name="commission_amount"
                        type="number"
                        min="0"
                        step="0.01"
                        placeholder="أدخل مبلغ العمولة"
                        class="form-control"
                        required
                    >
                    <i class="uil uil-money-bill"></i>
                </div>
            </div>
            <div class="col-md-4 mt-2">
                <div class="input-wrapper input-icon">
                    <label for="invoice_number_employee" class="input-label">رقم الفاتورة</label>
                    <input
                        id="invoice_number_employee"
                        name="invoice_number"
                        type="text"
                        placeholder="أدخل رقم الفاتورة"
                        class="form-control"
                        required
                    >
                    <i class="uil uil-receipt"></i>
                </div>
            </div>
            <!-- حذف رفع صورة الزيارة للموظف -->
        </div>
        <div class="row mb-2" id="marketer-fields">
            <div class="col-md-6">
                <div class="input-wrapper input-icon">
                    <label for="visitors_count_marketer" class="input-label">عدد الأشخاص</label>
                    <input
                        id="visitors_count_marketer"
                        name="visitors_count"
                        type="number"
                        min="0"
                        step="1"
                        placeholder="أدخل عدد الأشخاص"
                        class="form-control"
                    >
                    <i class="uil bi-person"></i>
                </div>
            </div>
            <div class="col-md-6">
                <div class="input-wrapper input-icon">
                    <label for="attach_marketer" class="input-label">رفع صورة الزيارة <span style="color: red;">*</span></label>
                    <input
                        id="attach_marketer"
                        name="attach"
                        type="file"
                        accept="image/*"
                        capture="environment"
                        class="form-control"
                        required
                    >
                    <i class="uil uil-image" style="position: absolute; right: 10px; top: 38px; pointer-events: none;"></i>
                    <div class="form-text mt-2" style="color: #dc3545; font-size: 1.25rem; font-weight: bold;">
                        يرجي تصوير سائق التاكسي بجانب السيارة مع وضوح لوحة السيارة
                    </div>
                </div>
            </div>
        </div>
    </div>
    <br/><br/>
</div>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const marketerFields = document.getElementById('marketer-fields');
        const employeeFields = document.getElementById('employee-fields');
        const marketerRadio = document.getElementById('type_marketer');
        const employeeRadio = document.getElementById('type_employee');

        // تعريف الحقول الخاصة بكل نوع
        const employeeInputs = [
            document.getElementById('visitors_count'),
            document.getElementById('cheque_amount'),
            document.getElementById('invoice_amount'),
            document.getElementById('dishes_count'),
            document.getElementById('commission_amount_employee'),
            document.getElementById('invoice_number_employee')
        ];

        const marketerInputs = [
            document.getElementById('visitors_count_marketer'),
            document.getElementById('attach_marketer')
        ];

        function toggleFields() {
            if (employeeRadio.checked) {
                // إظهار حقول الموظف
                employeeFields.style.display = 'flex';
                marketerFields.style.display = 'none';

                // اجعل حقول الموظف required ومفعلة
                employeeInputs.forEach(input => {
                    if (input) {
                        input.required = true;
                        input.disabled = false;
                    }
                });

                // الغي required من حقول المسوق وعطلها
                marketerInputs.forEach(input => {
                    if (input) {
                        input.required = false;
                        input.disabled = true;
                    }
                });

            } else if (marketerRadio.checked) {
                // إظهار حقول المسوق
                marketerFields.style.display = 'flex';
                employeeFields.style.display = 'none';

                // اجعل حقول المسوق required ومفعلة
                marketerInputs.forEach(input => {
                    if (input) {
                        input.required = true;
                        input.disabled = false;
                    }
                });

                // الغي required من حقول الموظف وعطلها
                employeeInputs.forEach(input => {
                    if (input) {
                        input.required = false;
                        input.disabled = true;
                    }
                });
            }
        }

        // لما يغيّر الاختيار
        marketerRadio.addEventListener('change', toggleFields);
        employeeRadio.addEventListener('change', toggleFields);

        // أول مرة يفتح الصفحة يطبق المنطق
        toggleFields();
    });
</script>
</div>

</div>
</div>
<div class="modal-footer">
    <button type="submit" class="btn btn-primary">إضافة</button>
    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
</div>
</form>
<script>
    //699942
    document.addEventListener('DOMContentLoaded', function() {
        const detailUrlBase = "{{ url('marketers/details') }}/";
        const marketerInput = document.getElementById('marketer_code');
        const detailsDiv = document.getElementById('marketer-details');
        const extraFields = document.getElementById('extra-fields');
        if (marketerInput) {
            marketerInput.addEventListener('input', function() {
                const code = this.value.trim();

                if (!code) {
                    detailsDiv.style.display = 'none';
                    detailsDiv.innerHTML = '';
                    extraFields.style.display = 'none';
                    return;
                }

                fetch(detailUrlBase + code)
                    .then(resp => {
                        if (!resp.ok) throw new Error("Marketer not found");
                        return resp.json();
                    })
                    .then(data => {
                        detailsDiv.innerHTML = `
                            <div class="alert alert-info">
                                <strong>اسم المسوق:</strong> ${data.name}<br>
                                <strong>رقم الهاتف:</strong> ${data.phone}<br>
                                <strong>كود التسويق:</strong> ${data.marketing_code}<br>
                                <strong>الموقع:</strong> ${data.site ? data.site : 'غير محدد'}<br>
                                <strong>الموظف:</strong> ${data.employee ? data.employee : 'غير محدد'}<br>
                            </div>
                        `;
                        detailsDiv.style.display = 'block';
                        extraFields.style.display = 'block';
                    })
                    .catch(err => {
                        detailsDiv.innerHTML = '<div class="alert alert-danger">لم يتم العثور على تفاصيل المسوق.</div>';
                        detailsDiv.style.display = 'block';
                        extraFields.style.display = 'none';
                    });
            });
        }
    });
</script>

    </div>
  </div>
</div>
       </div>          <!-- End:: Add Company -->

                        <div class="card-body">
                            <div class="table-responsive">
                            <form method="GET" action="{{ route('commissions.index') }}" class="row g-2 align-items-center justify-content-end mb-3" id="commission-search-form">
                                <div class="col-md-4 col-lg-3">
                                    <input type="text" name="search" value="{{ request('search') }}" class="form-control rounded-pill px-4" placeholder="ابحث باسم الموقع أو المسوق أو اسم المستخدم..." id="commission-search-input" autocomplete="off" style="background-color: #f8f9fa;">
                                </div>
                                <div class="col-md-2 col-lg-1">
                                    <button type="submit" class="btn btn-primary btn-sm w-100 rounded-pill">
                                        <i class="bi bi-search"></i> بحث
                                    </button>
                                </div>
                                @if(request('search'))
                                <div class="col-md-2 col-lg-1">
                                    <a href="{{ route('commissions.index') }}" class="btn btn-secondary btn-sm w-100 rounded-pill">
                                        <i class="bi bi-x"></i> إلغاء
                                    </a>
                                </div>
                                @endif
                            </form>
                            <script>
                                    document.addEventListener('DOMContentLoaded', function () {
                                        let timer;
                                        const input = document.getElementById('commission-search-input');
                                        const form = document.getElementById('commission-search-form');
                                        if (input && form) {
                                            input.addEventListener('input', function () {
                                                clearTimeout(timer);
                                                timer = setTimeout(function () {
                                                    form.submit();
                                                }, 500); // delay for user typing
                                            });
                                        }
                                    });
                                </script>
                                <table class="table text-nowrap table-bordered border-primary">
                                    <thead>
                                        <tr>
                                            <th scope="col">م</th>
                                            <th scope="col">الموقع</th>
                                            <th scope="col">المسوّق</th>
                                            <th scope="col">عدد الزوار</th>
                                            <th scope="col">عدد الأطباق</th>
                                            <th scope="col"> رصيد العمولات الحاليه</th>
                                            <th scope="col">مبلغ الفاتورة</th>
                                            <th scope="col">اسم المستخدم</th>
                                            <th scope="col">تاريخ الإضافة</th>
                                            <th scope="col">صورة الزيارة</th>
                                              <th scope="col">إضافة عمولة</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        @forelse($commissions as $index => $commission)
                                            <tr>
                                                <td>{{ $loop->iteration }}</td>
                                                <td>{{ $commission->site?->name ?? '—' }}</td>
                                                <td>{{ $commission->marketer?->name ?? '—' }}</td>
                                                <td>{{ $commission->visitors }}</td>
                                                <td>{{ $commission->dishes }}</td>
                                                <td>{{ number_format($commission->received == 1 ? 0 : $commission->commission_amount, 2) }}</td>
                                                <td>{{ number_format($commission->invoice_amount, 2) }}</td>
                                                <td>{{ $commission->creator?->name ?? '—' }}</td>
                                                <td>
                                                    {{ $commission->created_at->format('Y-m-d') }}<br>
                                                    <small>{{ $commission->created_at->translatedFormat('h:i A') }}</small>
                                                </td>
                                                  <td>
                                                    <a href="{{ route('commissions.invoice', $commission->id) }}" style='display: none;' target="_blank" class="btn btn-sm btn-info">
                                                        <i class="ri-printer-line"></i> طباعة
                                                    </a>
                                                    @if($commission->attach)
                                                        <button type="button" class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#visitImageModal-{{ $commission->id }}">
                                                            <i class="ri-image-line"></i> صورة الزيارة
                                                        </button>
                                                        <!-- Modal -->
                                                        <div class="modal fade" id="visitImageModal-{{ $commission->id }}" tabindex="-1" aria-labelledby="visitImageModalLabel-{{ $commission->id }}" aria-hidden="true">
                                                            <div class="modal-dialog modal-dialog-centered">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title" id="visitImageModalLabel-{{ $commission->id }}">صورة الزيارة</h5>
                                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="إغلاق"></button>
                                                                    </div>
                                                                    <div class="modal-body text-center">
                                                                        <img src="{{ asset('storage/' . $commission->attach) }}" alt="صورة الزيارة" class="img-fluid rounded" style="max-height:400px;">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    @else
                                                        <span class="text-muted">لا يوجد صورة</span>
                                                    @endif
                                                </td>
                                                <td>
                                                    <button type="button"
                                                        class="btn btn-sm btn-success"
                                                        data-bs-toggle="modal"
                                                        data-bs-target="#completeCommissionModal-{{ $commission->id }}">
                                                        <i class="ri-add-line"></i> إضافة عمولة
                                                    </button>
                                                    <!-- Modal -->
                                                    <div class="modal fade"
                                                        id="completeCommissionModal-{{ $commission->id }}"
                                                        tabindex="-1"
                                                        aria-labelledby="completeCommissionModalLabel-{{ $commission->id }}"
                                                        aria-hidden="true">
                                                        <div class="modal-dialog">
                                                            <div class="modal-content">
                                                                <form method="POST" action="{{ route('commissions.complete', $commission->id) }}" enctype="multipart/form-data">
                                                                    @csrf
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title" id="completeCommissionModalLabel-{{ $commission->id }}">إضافة بيانات العمولة  -   {{ $commission->marketer?->name ?? '—' }} </h5>

                                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <div class="mb-3">
                                                                            <label for="dishes_count-{{ $commission->id }}" class="form-label">عدد الأطباق</label>
                                                                            <input type="number" min="0" class="form-control" id="dishes_count-{{ $commission->id }}" name="dishes_count" value="{{ $commission->dishes }}">
                                                                        </div>
                                                                        <div class="mb-3">
                                                                            <label for="commission_amount-{{ $commission->id }}" class="form-label">مبلغ العمولة</label>
                                                                            <input type="number" min="0" step="0.01" class="form-control" id="commission_amount-{{ $commission->id }}" name="commission_amount" value="{{ $commission->commission_amount }}">
                                                                        </div>
                                                                        <div class="mb-3">
                                                                            <label for="invoice_amount-{{ $commission->id }}" class="form-label">مبلغ الفاتورة</label>
                                                                            <input type="number" min="0" step="0.01" class="form-control" id="invoice_amount-{{ $commission->id }}" name="invoice_amount" value="{{ $commission->invoice_amount }}">
                                                                        </div>
                                                                        <div class="mb-3">
                                                                            <label for="invoice_number-{{ $commission->id }}" class="form-label">رقم الفاتورة</label>
                                                                            <input type="text" class="form-control" id="invoice_number-{{ $commission->id }}" name="invoice_number" value="{{ $commission->invoice_number }}">
                                                                        </div>
                                                                        <div class="mb-3">
                                                                            <label for="invoice_image-{{ $commission->id }}" class="form-label">صورة الفاتورة</label>
                                                                            <input type="file" class="form-control" id="invoice_image-{{ $commission->id }}" name="invoice_image" accept="image/*">
                                                                            @if($commission->invoice_image)
                                                                                <div class="mt-2">
                                                                                    <a href="{{ asset('storage/' . $commission->invoice_image) }}" target="_blank" class="btn btn-sm btn-info">
                                                                                        <i class="ri-image-line"></i> عرض صورة الفاتورة الحالية
                                                                                    </a>
                                                                                </div>
                                                                            @endif
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="submit" class="btn btn-primary">إضافة</button>
                                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>

                                            </tr>
                                        @empty
                                            <tr>
                                                <td colspan="11" class="text-center">لا توجد بيانات حتى الآن.</td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                                 <div class="d-flex justify-content-center mt-4">
    {{ $commissions->onEachSide(1)->links('vendor.pagination.bootstrap-5') }}
</div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <!-- End:: row-1 -->



        </div>
    </div>
    <!-- End::app-content -->

@endsection
