@extends('layout.app')

@section('title', 'المجموعات')

@section('content')
<div class="main-content app-content">
    <div class="container-fluid">

        @include('partials.crumb')

        <div class="row">
            <div class="col-xl-12">
                <div class="card custom-card">
                    <div class="card-header justify-content-between">
                        <div class="card-title">
                            المجموعات
                        </div>
                        <div class="d-flex flex-wrap gap-2">
                            <a href="{{ route('roles.create') }}" class="btn btn-primary btn-sm btn-wave">
                                <i class="ri-add-line me-1 fw-medium align-middle"></i> إضافة مجموعة
                            </a>
                            <a href="{{ route('permissions.index') }}" class="btn btn-info btn-sm btn-wave">
                                <i class="bi bi-shield-lock me-1 fw-medium align-middle"></i> الصلاحيات
                            </a>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table text-nowrap table-bordered border-primary">
                                <thead>
                                    <tr>
                                        <th>م</th>
                                        <th>الاسم</th>
                                        <th>الصلاحيات</th>
                                        <th>المستخدمين</th>
                                        <th>تحكم</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($roles as $role)
                                        <tr>
                                            <td>{{ $loop->iteration }}</td>
                                            <td>
    {{ __("roles." . $role->name) ?? $role->name }}
</td>
<td>
    <button type="button" class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#permissionsModal{{ $role->id }}">
        عرض الصلاحيات <span class="badge bg-light text-dark">{{ $role->permissions->count() }}</span>
    </button>

    <!-- Modal -->
    <div class="modal fade" id="permissionsModal{{ $role->id }}" tabindex="-1" aria-labelledby="permissionsModalLabel{{ $role->id }}" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="permissionsModalLabel{{ $role->id }}">صلاحيات : {{ __("roles." . $role->name) ?? $role->name }}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="إغلاق"></button>
                </div>
                <div class="modal-body">
                    <div class="container-fluid">
                        @if($role->permissions->isEmpty())
                            <div class="text-muted text-center">لا توجد صلاحيات</div>
                        @else
                            <div class="row">
                                @foreach($role->permissions->chunk(3) as $chunk)
                                    <div class="d-flex mb-2">
                                        @foreach($chunk as $permission)
                                            <div class="flex-fill me-2">
                                                <span class="badge bg-light text-dark d-flex align-items-center p-2">
                                                    <i class="bi bi-shield-check text-success me-2"></i>
                                                    {{ __("permissions." . $permission->name) ?? $permission->name }}
                                                </span>
                                            </div>
                                        @endforeach
                                    </div>
                                @endforeach
                            </div>
                        @endif
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
                </div>
            </div>
        </div>
    </div>
</td>
                                            <td>
    @foreach($role->users as $user)
        <span class="badge bg-secondary">{{ $user->name }}</span>
    @endforeach
</td>
                                            <td>
                                                <a href="{{ route('roles.edit', $role) }}" class="btn btn-sm btn-outline-warning me-1" title="تعديل">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                                <form action="{{ route('roles.destroy', $role) }}" method="POST" class="d-inline">
                                                    @csrf @method('DELETE')
                                                    <button onclick="return confirm('هل تريد الحذف؟')" class="btn btn-sm btn-outline-danger" title="حذف">
                                                        <i class="bi bi-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                            <div class="d-flex justify-content-center mt-4">
                                {{ $roles->onEachSide(1)->links('vendor.pagination.bootstrap-5') }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
@endsection
