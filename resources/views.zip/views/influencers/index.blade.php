@extends('layout.app')

@section('title', 'مشاهير الاعلانات')

@section('content')
    <!-- Start::app-content -->
    <div class="main-content app-content">
        <div class="container-fluid">

            @include('partials.crumb')


            <!-- Start:: row-1 -->
            <div class="row">
                <div class="col-xl-12">
                    <div class="card custom-card">
                        <div class="card-header justify-content-between">
                            <div class="card-title">
                                مشاهير الاعلانات
                            </div>

                                 <div class="d-flex flex-wrap gap-2">
 <a href="{{ route('countries.index') }}" class="btn btn-primary btn-sm btn-wave">
       الدول
    </a>
    <button class="btn btn-primary btn-sm btn-wave" data-bs-toggle="modal" data-bs-target="#addMarketerModal">
        <i class="ri-add-line me-1 fw-medium align-middle"></i> إضافة مشهور جديد
    </button>
                                </div>

                        </div>
                           <!-- Start:: Add Company -->
                <div class="modal fade" id="addMarketerModal" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <form action="{{ route('influencers.store') }}" method="POST" enctype="multipart/form-data">
                                @csrf
                                <div class="modal-header">
                                    <h6 class="modal-title">إضافة مشهور جديد</h6>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <div class="modal-body px-4">
                                    <div class="row gy-3">
                                        <div class="col-md-6">
                                            <label for="input-name" class="form-label">اسم المشهور</label>
                                            <input id="input-name" type="text" name="name" placeholder="أدخل اسم المشهور" class="form-control" required>
                                        </div>
                                        <div class="col-md-6">
                                            <label for="input-ads-link" class="form-label">رابط الإعلانات</label>
                                            <input id="input-ads-link" type="url" name="ads_link" placeholder="أدخل رابط الإعلانات" class="form-control">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="input-country" class="form-label">الدولة</label>
                                            <select id="input-country" name="country_id" class="form-control">
                                                <option value="" disabled selected>اختر الدولة</option>
                                                @foreach($countries as $country)
                                                    <option value="{{ $country->id }}">{{ $country->name }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <label for="input-whatsapp-link" class="form-label">رابط واتساب</label>
                                            <input id="input-whatsapp-link" type="url" name="whatsapp_link" placeholder="أدخل رابط واتساب" class="form-control">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="input-instagram-link" class="form-label">رابط انستجرام</label>
                                            <input id="input-instagram-link" type="url" name="instagram_link" placeholder="أدخل رابط انستجرام" class="form-control">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="input-tiktok-link" class="form-label">رابط تيك توك</label>
                                            <input id="input-tiktok-link" type="url" name="tiktok_link" placeholder="أدخل رابط تيك توك" class="form-control">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="input-snap" class="form-label">سناب شات</label>
                                            <input id="input-snap" type="text" name="snap" placeholder="أدخل اسم سناب شات" class="form-control" maxlength="255">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="input-snap-link" class="form-label">رابط سناب شات</label>
                                            <input id="input-snap-link" type="url" name="snap_link" placeholder="أدخل رابط سناب شات" class="form-control" maxlength="255">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="input-phone" class="form-label">رقم الهاتف</label>
                                            <input id="input-phone" type="text" name="phone" placeholder="أدخل رقم الهاتف" class="form-control" maxlength="20">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="input-employee" class="form-label">الموظف</label>
                                            <select id="input-employee" name="employee_id" class="form-control" required>
                                                <option value="" disabled selected>اختر الموظف</option>
                                                @foreach($employees as $id => $emp)
                                                    <option value="{{ $id }}">{{ $emp }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <label for="input-balance" class="form-label">الرصيد</label>
                                            <input id="input-balance" type="number" name="balance" placeholder="أدخل الرصيد" class="form-control" step="0.01" min="0">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="input-pdf" class="form-label">ملف PDF</label>
                                            <input id="input-pdf" type="file" name="pdf" class="form-control" accept="application/pdf">
                                            <small class="text-muted">الحد الأقصى 20MB</small>
                                        </div>
                                        <div class="col-12">
                                            <label for="input-notes" class="form-label">ملاحظات</label>
                                            <textarea id="input-notes" name="notes" class="form-control" rows="10" placeholder="أدخل ملاحظات" maxlength="2000" style="min-height:220px;"></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary">إضافة</button>
                                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">الغاء</button>
                                </div>
                            </form>
                        </div>
                        </div>
                    </div>
               
                <!-- End:: Add Company -->

                        <div class="card-body">
                            <div class="table-responsive">
                                <div class="mb-3">
                                    <form method="GET" action="{{ route('influencers.index') }}" class="row g-2 align-items-center justify-content-end" id="marketer-search-form">
                                        <div class="col-md-4 col-lg-3">
                                            <input type="text" name="search" value="{{ request('search') }}" class="form-control rounded-pill px-4" placeholder="ابحث باسم المسوق أو رقم الهاتف..." id="marketer-search-input" autocomplete="off" style="background-color: #f8f9fa;">
                                        </div>
                                        <div class="col-md-2 col-lg-1">
                                            <button type="submit" class="btn btn-primary btn-sm w-100 rounded-pill">
                                                <i class="bi bi-search"></i> بحث
                                            </button>
                                        </div>
                                        @if(request('search'))
                                        <div class="col-md-2 col-lg-1">
                                            <a href="{{ route('marketers.index') }}" class="btn btn-secondary btn-sm w-100 rounded-pill">
                                                <i class="bi bi-x"></i> إلغاء
                                            </a>
                                        </div>
                                        @endif
                                    </form>
                                </div>
                                <script>
                                    document.addEventListener('DOMContentLoaded', function () {
                                        let timer;
                                        const input = document.getElementById('marketer-search-input');
                                        const form = document.getElementById('marketer-search-form');
                                        input.addEventListener('input', function () {
                                            clearTimeout(timer);
                                            timer = setTimeout(function () {
                                                form.submit();
                                            }, 500); // delay for user typing
                                        });
                                    });
                                </script>
                                <table class="table text-nowrap table-bordered border-primary">
                                    <thead>
                                        <tr>
                                            <th scope="col">م</th>
                                            <th scope="col">اسم المشهور</th>
                                            <th scope="col">الموظف</th>
                                            <th scope="col">الدولة</th>
                                            <th scope="col">الرصيد الافتتاحي</th>
                                            <th scope="col">الرصيد الحالي</th>
                                            <th scope="col">الرصيد المسحوب</th>
                                            <th scope="col">إجمالي الزيارات</th>
<th scope="col">متوسط التقييم (مُعلَن)</th>
                                            <th scope="col">اخر عملية تمت</th>
                                            <th scope="col">روابط التواصل</th>
                                            <th scope="col">ملاحظات</th>
                                            <th scope="col">اجراءات</th>
                                            <th scope="col">عمليات</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($influencers as $influencer)
                                        <tr>
                                            <td>{{ $loop->iteration }}</td>
                                            <td>{{ $influencer->name }}</td>
                                            <td>{{ $influencer->employee->name ?? '-' }}</td>
                                            <td>{{ $influencer->country->name ?? '-' }}</td>
                                            <td>{{ number_format($influencer->basic_balance, 2) }}</td>
                                            <td>{{ number_format($influencer->balance, 2) }}</td>
                                            <td>{{ number_format(($influencer->basic_balance - $influencer->balance), 2) }}</td>
                                            <td>
                                                <div>
                                                    <span>مُعلَن: {{ $influencer->announced_visits_count ?? 0 }}</span><br>
                                                    <span>غير مُعلَن: {{ $influencer->visits_count - ($influencer->announced_visits_count ?? 0) }}</span>
                                                </div>
                                            </td>
<td>
  @if(!is_null($influencer->announced_avg_rating))
      {{ number_format($influencer->announced_avg_rating, 2) }}
      {{-- اختياري: عرض عدد الزيارات المُعلَنَة --}}
      <small class="text-muted">({{ $influencer->announced_visits_count }} زيارة)</small>
  @else
      -
  @endif
</td>
                                           <td>
  @if($influencer->latestOperation)
    {{ $influencer->latestOperation->operation_type === 'recharge' ? 'شحن' : 'زيارة' }}
    <br/>{{ $influencer->latestOperation->created_at->format('Y-m-d H:i') }}
  @else
    لا يوجد عمليات
  @endif
</td>
                                            <td>
                                                <div class="d-flex flex-wrap gap-2">
                                                    @if($influencer->ads_link)
                                                        <a href="{{ $influencer->ads_link }}" target="_blank" title="رابط الإعلانات">
                                                            <i class="bi bi-link-45deg fs-5"></i>
                                                        </a>
                                                    @endif
                                                    @if($influencer->whatsapp_link)
                                                        <a href="{{ $influencer->whatsapp_link }}" target="_blank" title="واتساب">
                                                            <i class="bi bi-whatsapp fs-5"></i>
                                                        </a>
                                                    @endif
                                                    @if($influencer->instagram_link)
                                                        <a href="{{ $influencer->instagram_link }}" target="_blank" title="انستجرام">
                                                            <i class="bi bi-instagram fs-5"></i>
                                                        </a>
                                                    @endif
                                                    @if($influencer->tiktok_link)
                                                        <a href="{{ $influencer->tiktok_link }}" target="_blank" title="تيك توك">
                                                            <i class="bi bi-tiktok fs-5"></i>
                                                        </a>
                                                    @endif
                                                    @if($influencer->snap_link)
                                                        <a href="{{ $influencer->snap_link }}" target="_blank" title="سناب شات">
                                                            <i class="bi bi-snapchat fs-5"></i>
                                                        </a>
                                                    @endif
                                                    @if($influencer->phone)
                                                        <a href="tel:{{ $influencer->phone }}" title="اتصال">
                                                            <i class="bi bi-telephone fs-5"></i>
                                                        </a>
                                                    @endif
                                                    @if($influencer->pdf)
                                                        <a href="{{ asset('storage/' . $influencer->pdf) }}" target="_blank" title="ملف PDF">
                                                            <i class="bi bi-file-earmark-pdf fs-5"></i>
                                                        </a>
                                                    @endif
                                                </div>
                                            </td>
                                            <td>{{ $influencer->notes }}</td>
                                            <td>
                                                <div class="d-flex flex-column gap-2">
                                                    <button class="btn btn-sm btn-outline-info"
                                                        data-bs-toggle="modal"
                                                        data-bs-target="#visitModal-{{ $influencer->id }}">
                                                        <i class="bi bi-box-arrow-up-right ms-1" title="زيارة جديدة"></i> زيارة جديدة
                                                    </button>
                                                    <button class="btn btn-sm btn-outline-success"
                                                        data-bs-toggle="modal"
                                                        data-bs-target="#chargeModal-{{ $influencer->id }}">
                                                        <i class="bi bi-cash-stack ms-1" title="شحن رصيد"></i> شحن رصيد
                                                    </button>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="d-flex flex-column align-items-center gap-1">
                                                    <button class="btn btn-outline-warning btn-sm w-100" data-bs-toggle="modal" data-bs-target="#editInfluencerModal-{{ $influencer->id }}" title="تعديل">
                                                        <i class="bi bi-pencil"></i>
                                                    </button>
                                                    <form action="{{ route('influencers.destroy', $influencer) }}" method="POST" class="w-100">
                                                        @csrf @method('DELETE')
                                                        <button onclick="return confirm('هل تريد الحذف؟')" class="btn btn-outline-danger btn-sm w-100" title="حذف">
                                                            <i class="bi bi-trash"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                        <!-- زيارة جديدة Modal -->
                                        <div class="modal fade" id="visitModal-{{ $influencer->id }}" tabindex="-1" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-centered">
                                                <div class="modal-content">
                                                    <form action="{{ route('influencers.addVisit', $influencer->id) }}" method="POST">
                                                        @csrf
                                                        <div class="modal-header">
                                                            <h5 class="modal-title">إضافة زيارة - {{ $influencer->name }}</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="mb-3">
                                                                <label class="form-label">المبلغ</label>
                                                                <input type="number" step="0.01" min="0.01" name="amount" class="form-control" required>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label class="form-label">عدد الأشخاص</label>
                                                                <input type="number" min="0" name="people_count" class="form-control">
                                                            </div>
                                                            <div class="mb-3">
                                                                <label class="form-label">ملاحظات</label>
                                                                <textarea name="notes" class="form-control" maxlength="1000" rows="3"></textarea>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="submit" class="btn btn-primary">زيارة</button>
                                                            <button type="button" class="btn btn-light" data-bs-dismiss="modal">إلغاء</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- شحن رصيد Modal -->
                                        <div class="modal fade" id="chargeModal-{{ $influencer->id }}" tabindex="-1" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-centered">
                                                <div class="modal-content">
                                                    <form action="{{ route('influencers.chargeBalance', $influencer->id) }}" method="POST">
                                                        @csrf
                                                        <div class="modal-header">
                                                            <h5 class="modal-title">شحن رصيد - {{ $influencer->name }}</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <label class="form-label">المبلغ</label>
                                                            <input type="number" step="0.01" min="0" name="charge_amount" class="form-control" required>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="submit" class="btn btn-success">شحن</button>
                                                            <button type="button" class="btn btn-light" data-bs-dismiss="modal">إلغاء</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Edit Influencer Modal -->
                                        <div class="modal fade" id="editInfluencerModal-{{ $influencer->id }}" tabindex="-1" aria-labelledby="editInfluencerModalLabel-{{ $influencer->id }}" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-centered">
                                                <div class="modal-content">
                                                    <form action="{{ route('influencers.update', $influencer) }}" method="POST" enctype="multipart/form-data">
                                                        @csrf
                                                        @method('PUT')
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="editInfluencerModalLabel-{{ $influencer->id }}">تعديل المشهور</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="إغلاق"></button>
                                                        </div>
                                                        <div class="modal-body px-4">
                                                            <div class="row gy-3">
                                                                <div class="col-md-6">
                                                                    <label for="edit-input-name-{{ $influencer->id }}" class="form-label">اسم المشهور</label>
                                                                    <input id="edit-input-name-{{ $influencer->id }}" type="text" name="name" value="{{ $influencer->name }}" class="form-control" required>
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <label for="edit-input-ads-link-{{ $influencer->id }}" class="form-label">رابط الإعلانات</label>
                                                                    <input id="edit-input-ads-link-{{ $influencer->id }}" type="url" name="ads_link" value="{{ $influencer->ads_link }}" class="form-control">
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <label for="edit-input-country-{{ $influencer->id }}" class="form-label">الدولة</label>
                                                                    <select id="edit-input-country-{{ $influencer->id }}" name="country_id" class="form-control">
                                                                        <option value="" disabled>اختر الدولة</option>
                                                                        @foreach($countries as $country)
                                                                            <option value="{{ $country->id }}" {{ $influencer->country_id == $country->id ? 'selected' : '' }}>{{ $country->name }}</option>
                                                                        @endforeach
                                                                    </select>
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <label for="edit-input-whatsapp-link-{{ $influencer->id }}" class="form-label">رابط واتساب</label>
                                                                    <input id="edit-input-whatsapp-link-{{ $influencer->id }}" type="url" name="whatsapp_link" value="{{ $influencer->whatsapp_link }}" class="form-control">
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <label for="edit-input-instagram-link-{{ $influencer->id }}" class="form-label">رابط انستجرام</label>
                                                                    <input id="edit-input-instagram-link-{{ $influencer->id }}" type="url" name="instagram_link" value="{{ $influencer->instagram_link }}" class="form-control">
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <label for="edit-input-tiktok-link-{{ $influencer->id }}" class="form-label">رابط تيك توك</label>
                                                                    <input id="edit-input-tiktok-link-{{ $influencer->id }}" type="url" name="tiktok_link" value="{{ $influencer->tiktok_link }}" class="form-control">
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <label for="edit-input-snap-{{ $influencer->id }}" class="form-label">سناب شات</label>
                                                                    <input id="edit-input-snap-{{ $influencer->id }}" type="text" name="snap" value="{{ $influencer->snap }}" class="form-control" maxlength="255">
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <label for="edit-input-snap-link-{{ $influencer->id }}" class="form-label">رابط سناب شات</label>
                                                                    <input id="edit-input-snap-link-{{ $influencer->id }}" type="url" name="snap_link" value="{{ $influencer->snap_link }}" class="form-control" maxlength="255">
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <label for="edit-input-phone-{{ $influencer->id }}" class="form-label">رقم الهاتف</label>
                                                                    <input id="edit-input-phone-{{ $influencer->id }}" type="text" name="phone" value="{{ $influencer->phone }}" class="form-control" maxlength="20">
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <label for="edit-input-employee-{{ $influencer->id }}" class="form-label">الموظف</label>
                                                                    <select id="edit-input-employee-{{ $influencer->id }}" name="employee_id" class="form-control" required>
                                                                        <option value="" disabled>اختر الموظف</option>
                                                                        @foreach($employees as $id => $emp)
                                                                            <option value="{{ $id }}" {{ $influencer->employee_id == $id ? 'selected' : '' }}>{{ $emp }}</option>
                                                                        @endforeach
                                                                    </select>
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <label for="edit-input-balance-{{ $influencer->id }}" class="form-label">الرصيد</label>
                                                                    <input id="edit-input-balance-{{ $influencer->id }}" type="number" name="balance" value="{{ $influencer->balance }}" class="form-control" step="0.01" min="0">
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <label for="edit-input-pdf-{{ $influencer->id }}" class="form-label">ملف PDF</label>
                                                                    <input id="edit-input-pdf-{{ $influencer->id }}" type="file" name="pdf" class="form-control" accept="application/pdf">
                                                                    <small class="text-muted">الحد الأقصى 20MB</small>
                                                                    @if($influencer->pdf)
                                                                        <div class="mt-2">
                                                                            <a href="{{ asset('storage/' . $influencer->pdf) }}" target="_blank" class="btn btn-sm btn-outline-secondary">
                                                                                <i class="bi bi-file-earmark-pdf"></i> عرض الملف الحالي
                                                                            </a>
                                                                        </div>
                                                                    @endif
                                                                </div>
                                                                <div class="col-12">
                                                                    <label for="edit-input-notes-{{ $influencer->id }}" class="form-label">ملاحظات</label>
                                                                    <textarea id="edit-input-notes-{{ $influencer->id }}" name="notes" class="form-control" rows="10"  maxlength="2000" style="min-height:220px;">{{ $influencer->notes }}</textarea>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="submit" class="btn btn-primary">تعديل</button>
                                                            <button type="button" class="btn btn-light" data-bs-dismiss="modal">إلغاء</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        @endforeach
                                    </tbody>
                                </table>
                                <div class="d-flex justify-content-center mt-4">
                                    {{ $influencers->onEachSide(1)->links('vendor.pagination.bootstrap-5') }}
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <!-- End:: row-1 -->



        </div>
    </div>
    <!-- End::app-content -->

@endsection
