@extends('layout.app')

@section('title', 'مواقع التسويق')
<style>
.breadcrumb .breadcrumb-item {
    display: flex;
    align-items: center;
}

.breadcrumb .breadcrumb-item + .breadcrumb-item::before {
    content: "»";
    padding: 0 0.5rem;
    color: #999;
    display: inline-block;
}
</style>


@section('content')
    <!-- Start::app-content -->
    <div class="main-content app-content">
        <div class="container-fluid">

            @include('partials.crumb')


            <!-- Start:: row-1 -->
            <div class="row">
                <div class="col-xl-12">
                    <div class="card custom-card">
                        <div class="card-header justify-content-between">
                            <div class="card-title">
                               مواقع التسويق
                            </div>

                                 <div class="d-flex flex-wrap gap-2">
                                    <button class="btn btn-primary btn-sm btn-wave" data-bs-toggle="modal" data-bs-target="#addSiteModal"><i class="ri-add-line me-1 fw-medium align-middle"></i> إضافة موقع جديد</button>

                                </div>

                        </div>
                           <!-- Start:: Add Company -->
                <div class="modal fade" id="addSiteModal" tabindex="-1" aria-labelledby="addSiteModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                         <div class="modal-header justify-content-between">
    <h6 class="modal-title" id="addSiteModalLabel">إضافة موقع جديد</h6>
    <button type="button" class="btn-close ms-0" data-bs-dismiss="modal" aria-label="إغلاق"></button>

</div>
                            <form action="{{ route('sites.store') }}" method="POST" class="geex-content__form">
                                @csrf
                                <div class="modal-body px-4">
                                    <div class="row gy-2">
                                        <div class="col-xl-12">
                                            <label for="name" class="form-label">اسم الموقع</label>
                                            <input type="text" class="form-control" id="name" name="name" placeholder="اسم الموقع" required>
                                        </div>
                                        <input type="hidden" name="parent_id" value="{{ request()->segment(2) }}">
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary">إضافة</button>
                                     <button type="button" class="btn btn-light" data-bs-dismiss="modal">إلغاء</button>

                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- End:: Add Company -->

                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table text-nowrap table-bordered border-primary">
                                    <thead>
                                        <tr>
                                            <th scope="col">م</th>
                                            <th scope="col">اسم الموقع الفرعي </th>
                                            <th scope="col"> عدد المسوقين</th>
                                            <th scope="col">عدد العملاء</th>
                                            <th scope="col">إجراءات</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                      @foreach($subsites as $sub)
          <tr>
            <td>{{ $loop->iteration }}</td>
            <td>{{ $sub->name }}</td>

            <td>
                <a href="{{ route('marketers.index', ['site_id' => request()->segment(2), 'subsite_id' => $sub->id]) }}" style="color: #007bff; text-decoration: underline;">
                    {{ $sub->marketers_count }}
                </a>
            </td>
            <td>
                <a href="#" style="color: #007bff; text-decoration: underline;">
                    {{ $sub->clients_count }}
                </a>
            </td>
            <td>
                <button class="btn btn-sm btn-outline-warning me-1" data-bs-toggle="modal" data-bs-target="#editSiteModal-{{ $sub->id }}" style="padding-right: 10px;padding-left: 10px;padding-top: 0px;padding-bottom: 0px;">
                       <i class="ri-edit-line"></i>
                </button>
                <!-- Edit Site Modal -->
                <div class="modal fade" id="editSiteModal-{{ $sub->id }}" tabindex="-1" aria-labelledby="editSiteModalLabel-{{ $sub->id }}" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content geex-content__form">
                            <form action="{{ route('sites.update', $sub) }}" method="POST">
                                @csrf @method('PUT')
                                <div class="modal-header">
                                    <h5 class="modal-title" id="editSiteModalLabel-{{ $sub->id }}">تعديل الموقع</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="إغلاق"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="geex-content__form__wrapper">
                                        <div class="geex-content__form__wrapper__item geex-content__form__right">
                                            <div class="geex-content__form__single">
                                                <div class="geex-content__form__single__box">
                                                    <div class="input-wrapper">
                                                        <label for="name-{{ $sub->id }}" class="input-label">اسم الموقع</label>
                                                        <input id="name-{{ $sub->id }}" name="name" value="{{ $sub->name }}" placeholder="اسم الموقع" class="form-control" required />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary">حفظ التعديلات</button>
                                    <button type="button" class="btn btn-warning" data-bs-dismiss="modal">إلغاء</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <form action="{{ route('sites.destroy', $sub) }}" method="POST" class="d-inline">
                    @csrf @method('DELETE')
                    <button onclick="return confirm('هل تريد الحذف؟')" class="btn btn-sm btn-outline-danger" style="padding-right: 10px;padding-left: 10px;padding-top: 0px;padding-bottom: 0px;">
                       <i class="ri-delete-bin-line"></i>
                    </button>
                </form>
            </td>
          </tr>
        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <!-- End:: row-1 -->



        </div>
    </div>
    <!-- End::app-content -->

@endsection
