@extends('layout.app')

@section('title', 'مواقع التسويق')

@section('content')
    <!-- Start::app-content -->
    <div class="main-content app-content">
        <div class="container-fluid">

            @include('partials.crumb')


            <!-- Start:: row-1 -->
            <div class="row">
                <div class="col-xl-12">
                    <div class="card custom-card">
                        <div class="card-header justify-content-between">
                            <div class="card-title">
                                مواقع التسويق
                            </div>

                            <div class="d-flex flex-wrap gap-2">
                                <button class="btn btn-primary btn-sm btn-wave" data-bs-toggle="modal"
                                    data-bs-target="#addSiteModal"><i class="ri-add-line me-1 fw-medium align-middle"></i>
                                    إضافة موقع جديد</button>

                            </div>

                        </div>
                        <!-- Start:: Add Company -->
                        <div class="modal fade" id="addSiteModal" tabindex="-1" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h6 class="modal-title">إضافة موقع جديد</h6>

                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

                                    </div>
                                    <div class="modal-body px-4">
                                        <div class="row gy-3">
                                            <div class="col-xl-12" style="display: none;">
                                                <div class="mb-0 text-center">
                                                    <span class="avatar avatar-xxl avatar-rounded p-2 bg-light">
                                                        <img src="{{ asset('assets/images/company-logos/11.png') }}" alt="" id="profile-img">
                                                        <span class="badge rounded-pill bg-primary avatar-badge">
                                                            <input type="file" name="photo"
                                                                class="position-absolute w-100 h-100 op-0"
                                                                id="profile-change">
                                                            <i class="fe fe-camera"></i>
                                                        </span>
                                                    </span>
                                                </div>
                                            </div>
                                            <form action="{{ route('sites.store') }}" method="POST">
                                                @csrf
                                                @method('POST')
                                                <div class="col-xl-12">
                                                    <label for="company-name" class="form-label">اسم الموقع </label>
                                                    <input type="text" class="form-control" id="name"
                                                        placeholder="اسم الموقع" name="name">
                                                </div>

                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-primary">حفظ </button>
                                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">الغاء</button>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <!-- End:: Add Company -->

                        <div class="card-body">
                            <div class="table-responsive">
                                <div class="mb-3">
                                    <form method="GET" action="{{ route('sites.index') }}"
                                        class="row g-2 align-items-center justify-content-end" id="site-search-form">
                                        <div class="col-md-4 col-lg-3">
                                            <input type="text" name="search" value="{{ request('search') }}"
                                                class="form-control rounded-pill px-4" placeholder="ابحث باسم الموقع..."
                                                id="site-search-input" autocomplete="off"
                                                style="background-color: #f8f9fa;">
                                        </div>
                                        <div class="col-md-2 col-lg-1">
                                            <button type="submit" class="btn btn-primary btn-sm w-100 rounded-pill">
                                                <i class="bi bi-search"></i> بحث
                                            </button>
                                        </div>
                                        @if (request('search'))
                                            <div class="col-md-2 col-lg-1">
                                                <a href="{{ route('sites.index') }}"
                                                    class="btn btn-secondary btn-sm w-100 rounded-pill">
                                                    <i class="bi bi-x"></i> إلغاء
                                                </a>
                                            </div>
                                        @endif
                                    </form>
                                </div>
                                <script>
                                    document.addEventListener('DOMContentLoaded', function() {
                                        let timer;
                                        const input = document.getElementById('site-search-input');
                                        const form = document.getElementById('site-search-form');
                                        input.addEventListener('input', function() {
                                            clearTimeout(timer);
                                            timer = setTimeout(function() {
                                                form.submit();
                                            }, 500);
                                        });
                                    });
                                </script>
                                <table class="table text-nowrap table-bordered border-primary">
                                    <thead>
                                        <tr>
                                            <th scope="col">م</th>
                                            <th scope="col">اسم الموقع</th>
                                            <th scope="col">المواقع الفرعية</th>
                                            <th scope="col">المسوّقون</th>
                                            <th scope="col">العملاء</th>
                                            <th scope="col">عمليات</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($sites as $site)
                                            <tr>
                                                <td>{{ $loop->iteration }}</td>
                                                <td>{{ $site->name }}</td>
                                                <td>
                                                    <a href="{{ route('sites.subsites.index', $site) }}"
                                                        class="text-primary fw-bold text-decoration-underline">
                                                        {{ $site->subs_count }}
                                                    </a>
                                                </td>
                                                <td>
                                                    <a href="{{ route('marketers.index', ['site_id' => $site->id]) }}"
                                                        class="text-primary fw-bold text-decoration-underline">
                                                        {{ $site->marketers_count }}
                                                    </a>
                                                </td>
                                                <td>
                                                    <a href="#"
                                                        class="text-primary fw-bold text-decoration-underline">
                                                        {{ $site->clients_count }}
                                                    </a>
                                                </td>
                                                <td>
                                                    <button class="btn btn-purple-light btn-wave" data-bs-toggle="modal"
                                                        data-bs-target="#editSiteModal-{{ $site->id }}">
                                                        <i class="ri-edit-line"></i>
                                                    </button>
                                                    <!-- Edit Site Modal -->
                                                    <div class="modal fade" id="editSiteModal-{{ $site->id }}"
                                                        tabindex="-1" aria-hidden="true">
                                                        <div class="modal-dialog modal-dialog-centered">
                                                            <div class="modal-content">
                                                                <form action="{{ route('sites.update', $site) }}"
                                                                    method="POST">
                                                                    @csrf
                                                                    @method('PUT')
                                                                    <div class="modal-header">
                                                                        <h6 class="modal-title">تعديل الموقع</h6>
                                                                        <button type="button" class="btn-close"
                                                                            data-bs-dismiss="modal"
                                                                            aria-label="Close"></button>
                                                                    </div>
                                                                    <div class="modal-body px-4">
                                                                        <div class="row gy-3">
                                                                            <div class="col-xl-12" style="display: none;">
                                                                                <div class="mb-0 text-center">
                                                                                    <span
                                                                                        class="avatar avatar-xxl avatar-rounded p-2 bg-light">
                                                                                        <img src="../assets/images/company-logos/11.png"
                                                                                            alt=""
                                                                                            id="profile-img">
                                                                                        <span
                                                                                            class="badge rounded-pill bg-primary avatar-badge">
                                                                                            <input type="file"
                                                                                                name="photo"
                                                                                                class="position-absolute w-100 h-100 op-0"
                                                                                                id="profile-change">
                                                                                            <i class="fe fe-camera"></i>
                                                                                        </span>
                                                                                    </span>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-xl-12">
                                                                                <label for="name-{{ $site->id }}"
                                                                                    class="form-label">اسم الموقع </label>
                                                                                <input type="text" class="form-control"
                                                                                    id="name-{{ $site->id }}"
                                                                                    placeholder="اسم الموقع"
                                                                                    name="name"
                                                                                    value="{{ $site->name }}">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="submit" class="btn btn-primary">حفظ
                                                                            التعديلات</button>
                                                                        <button type="button" class="btn btn-light"
                                                                            data-bs-dismiss="modal">الغاء</button>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <form action="{{ route('sites.destroy', $site) }}" method="POST"
                                                        class="d-inline">
                                                        @csrf @method('DELETE')
                                                        <button onclick="return confirm('هل تريد الحذف؟')"
                                                            class="btn btn-orange-light btn-wave">
                                                            <i class="bi bi-trash"></i>
                                                        </button>
                                                    </form>
                                                </td>
                                            </tr>
                                        @endforeach

                                    </tbody>
                                </table>
                                <div class="d-flex justify-content-center mt-4">
                                    {{ $sites->onEachSide(1)->links('vendor.pagination.bootstrap-5') }}
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <!-- End:: row-1 -->



        </div>
    </div>
    <!-- End::app-content -->

@endsection
