@extends('layout.app')

@section('title', 'الصلاحيات')

@section('content')
<div class="main-content app-content">
    <div class="container-fluid">
        @include('partials.crumb')

        <div class="row">
            <div class="col-xl-12">
                <div class="card custom-card">
                    <div class="card-header justify-content-between">
                        <div class="card-title">
                            الصلاحيات
                        </div>
                        <div class="d-flex flex-wrap gap-2">
                            <a href="{{ route('permissions.create') }}" class="btn btn-primary btn-sm btn-wave">
                                <i class="ri-add-line me-1 fw-medium align-middle"></i> إضافة صلاحية
                            </a>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table text-nowrap table-bordered border-primary">
                                <thead>
                                    <tr>
                                        <th scope="col">م</th>
                                        <th scope="col">الاسم</th>
                                        <th scope="col">تحكم</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($permissions as $permission)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
<td>{{ __("permissions." . $permission->name) ?? $permission->name }}</td>                                        <td>
                                            <a href="{{ route('permissions.edit', $permission) }}" class="btn btn-sm btn-outline-warning me-1" title="تعديل">
                                                <i class="bi bi-pencil"></i>
                                            </a>
                                            <form action="{{ route('permissions.destroy', $permission) }}" method="POST" class="d-inline">
                                                @csrf @method('DELETE')
                                                <button onclick="return confirm('هل تريد الحذف؟')" class="btn btn-sm btn-outline-danger" title="حذف">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                            <div class="d-flex justify-content-center mt-4">
                                {{ $permissions->onEachSide(1)->links('vendor.pagination.bootstrap-5') }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
