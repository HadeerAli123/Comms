@extends('layout.app')

@section('title', 'المسوقين')

@section('content')
    <!-- Start::app-content -->
    <div class="main-content app-content">
        <div class="container-fluid">

            @include('partials.crumb')


            <!-- Start:: row-1 -->
            <div class="row">
                <div class="col-xl-12">
                    <div class="card custom-card">
                        <div class="card-header justify-content-between">
                            <div class="card-title">
                                المسوقين
                            </div>

                                 <div class="d-flex flex-wrap gap-2">
                                    <button class="btn btn-primary btn-sm btn-wave" data-bs-toggle="modal" data-bs-target="#addMarketerModal"><i class="ri-add-line me-1 fw-medium align-middle"></i> إضافة مسوق جديد</button>

                                </div>

                        </div>
                           <!-- Start:: Add Company -->
                <div class="modal fade" id="addMarketerModal" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <form action="{{ route('marketers.store') }}" method="POST">
                                @csrf
                                <div class="modal-header">
                                    <h6 class="modal-title">إضافة مسوق جديد</h6>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body px-4">
                                    <div class="row gy-3">
                                        <!-- فقط إدخال بيانات المسوق، لا يوجد اختيار نوع الإدخال أو الموظف -->
                                        <div class="col-xl-12" style="display: none;">
                                            <div class="mb-0 text-center">
                                                <span class="avatar avatar-xxl avatar-rounded p-2 bg-light">
                                                    <img src="../assets/images/company-logos/11.png" alt="" id="profile-img">
                                                    <span class="badge rounded-pill bg-primary avatar-badge">
                                                        <input type="file" name="photo" class="position-absolute w-100 h-100 op-0" id="profile-change">
                                                        <i class="fe fe-camera"></i>
                                                    </span>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-xl-12">
                                            <label for="geex-input-name" class="form-label">اسم المسوق</label>
                                            <div class="input-wrapper input-icon">
                                                <input id="geex-input-name" type="text" name="name" placeholder="أدخل اسم المسوق" class="form-control" required>
                                                <i class="uil uil-user"></i>
                                            </div>
                                        </div>
                                        <div class="col-xl-12">
                                            <label for="geex-input-phone" class="form-label">رقم الهاتف</label>
                                            <div class="input-wrapper input-icon position-relative">
                                                <div class="input-group">
                                                    <span class="input-group-text p-0" style="min-width: 110px;">
                                                        <img id="selected-flag-img" src="{{ asset('flags/sa.png') }}" alt="flag" style="width: 24px; height: 18px; margin-right: 5px;">
                                                        <select name="country_code" id="country-code-select" class="form-select border-0 bg-transparent px-2" style="width: 80px;" required>
                                                            <option value="+966" selected data-flag="sa" data-flag-src="{{ asset('assets/flags/sa.png') }}">+966</option>
                                                            <option value="+20" data-flag="eg" data-flag-src="{{ asset('assets/flags/eg.png') }}">+20</option>
                                                            <option value="+971" data-flag="ae" data-flag-src="{{ asset('assets/flags/ae.png') }}">+971</option>
                                                            <option value="+965" data-flag="kw" data-flag-src="{{ asset('assets/flags/kw.png') }}">+965</option>
                                                            <option value="+964" data-flag="iq" data-flag-src="{{ asset('assets/flags/iq.png') }}">+964</option>
                                                            <option value="+962" data-flag="jo" data-flag-src="{{ asset('assets/flags/jo.png') }}">+962</option>
                                                            <option value="+963" data-flag="sy" data-flag-src="{{ asset('assets/flags/sy.png') }}">+963</option>
                                                            <option value="+968" data-flag="om" data-flag-src="{{ asset('assets/flags/om.png') }}">+968</option>
                                                            <option value="+973" data-flag="bh" data-flag-src="{{ asset('assets/flags/bh.png') }}">+973</option>
                                                            <option value="+974" data-flag="qa" data-flag-src="{{ asset('assets/flags/qa.png') }}">+974</option>
                                                        </select>
                                                    </span>
                                                    <input id="geex-input-phone" type="text" name="phone" placeholder="أدخل رقم الهاتف" class="form-control" required>
                                                    <span class="input-group-text"><i class="uil uil-phone"></i></span>
                                                </div>
                                                <div id="phone-validation-message" class="mt-2"></div>
                                            </div>
                                        </div>
                                        <div class="col-xl-12">
                                            <label for="geex-input-employee" class="form-label">الموظف</label>
                                            <select id="geex-input-employee" name="employee_id" class="form-control" required>
                                                <option value="" disabled {{ !old('employee_id', auth()->user()->id ?? null) ? 'selected' : '' }}>اختر الموظف</option>
                                                @foreach($employees as $id => $emp)
                                                    <option value="{{ $id }}" {{ old('employee_id', auth()->user()->id ?? null) == $id ? 'selected' : '' }}>{{ $emp }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <div class="col-xl-12">
                                            <label for="geex-input-location" class="form-label">الموقع</label>
                                            <div class="input-wrapper input-icon">
                                                <select id="geex-input-location" name="site_id" class="form-control" required>
                                                    <option value="" disabled {{ request('site_id') ? '' : 'selected' }}>اختر الموقع</option>
                                                    @foreach($sites as $id => $site)
                                                        <option value="{{ $id }}" {{ request('site_id') == $id ? 'selected' : '' }}>{{ $site }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-xl-12" id="branch-dropdown-container" style="{{ request('subsite_id') ? '' : 'display: none;' }}">
                                            <label for="geex-input-branch" class="form-label">الفرع</label>
                                            <div class="input-wrapper input-icon">
                                                <select id="geex-input-branch" name="branch_id" class="form-control">
                                                    <option value="" disabled {{ request('subsite_id') ? '' : 'selected' }}>اختر الفرع</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <script>
                                        document.addEventListener('DOMContentLoaded', function () {
                                            // Country flag logic
                                            const countryCodeSelect = document.getElementById('country-code-select');
                                            const flagImg = document.getElementById('selected-flag-img');
                                            function updateFlag() {
                                                const selectedOption = countryCodeSelect.options[countryCodeSelect.selectedIndex];
                                                const flagSrc = selectedOption.getAttribute('data-flag-src');
                                                if(flagSrc) {
                                                    flagImg.src = flagSrc;
                                                }
                                            }
                                            countryCodeSelect.addEventListener('change', updateFlag);
                                            updateFlag();

                                            // Branch dropdown logic
                                            const siteSelect = document.getElementById('geex-input-location');
                                            const branchContainer = document.getElementById('branch-dropdown-container');
                                            const branchSelect = document.getElementById('geex-input-branch');
                                            const subsiteId = "{{ request('subsite_id') }}";

                                            function loadBranches(siteId, selectedBranchId = null) {
                                                if (!siteId) {
                                                    branchContainer.style.display = 'none';
                                                    branchSelect.innerHTML = '<option value="" disabled selected>اختر الفرع</option>';
                                                    return;
                                                }
                                                fetch(`/api/sites/${siteId}/branches`)
                                                    .then(response => response.json())
                                                    .then(data => {
                                                        if (data.length > 0) {
                                                            branchSelect.innerHTML = '<option value="" disabled>اختر الفرع</option>';
                                                            data.forEach(branch => {
                                                                let selected = '';
                                                                if (selectedBranchId && branch.id == selectedBranchId) {
                                                                    selected = 'selected';
                                                                }
                                                                branchSelect.innerHTML += `<option value="${branch.id}" ${selected}>${branch.name}</option>`;
                                                            });
                                                            branchContainer.style.display = '';
                                                        } else {
                                                            branchContainer.style.display = 'none';
                                                            branchSelect.innerHTML = '<option value="" disabled selected>اختر الفرع</option>';
                                                        }
                                                    })
                                                    .catch(() => {
                                                        branchContainer.style.display = 'none';
                                                        branchSelect.innerHTML = '<option value="" disabled selected>اختر الفرع</option>';
                                                    });
                                            }

                                            if (siteSelect.value && subsiteId) {
                                                loadBranches(siteSelect.value, subsiteId);
                                            }

                                            siteSelect.addEventListener('change', function () {
                                                loadBranches(this.value, null);
                                            });

                                            // Phone validation logic
                                            const phoneInput = document.getElementById('geex-input-phone');
                                            const phoneMessage = document.getElementById('phone-validation-message');

                                            function validatePhone(countryCode, phone) {
                                                // Basic patterns for some countries
                                                const patterns = {
                                                    '+966': /^5\d{8}$/,      // Saudi: 9 digits, starts with 5
                                                    '+20': /^1\d{9}$/,       // Egypt: 10 digits, starts with 1
                                                    '+971': /^5\d{8}$/,      // UAE: 9 digits, starts with 5
                                                    '+965': /^[569]\d{7}$/,  // Kuwait: 8 digits, starts with 5,6,9
                                                    '+964': /^7\d{9}$/,      // Iraq: 10 digits, starts with 7
                                                    '+962': /^7\d{8}$/,      // Jordan: 9 digits, starts with 7
                                                    '+963': /^9\d{8}$/,      // Syria: 9 digits, starts with 9
                                                    '+968': /^9\d{7}$/,      // Oman: 8 digits, starts with 9
                                                    '+973': /^3\d{7}$/,      // Bahrain: 8 digits, starts with 3
                                                    '+974': /^3\d{7}$/,      // Qatar: 8 digits, starts with 3
                                                };
                                                const pattern = patterns[countryCode];
                                                if (!pattern) return false;
                                                return pattern.test(phone);
                                            }

                                            function showMessage(msg, type) {
                                                phoneMessage.textContent = msg;
                                                phoneMessage.style.color = type === 'success' ? 'green' : 'red';
                                            }

                                            function checkPhone() {
                                                const countryCode = countryCodeSelect.value;
                                                const phone = phoneInput.value.trim();
                                                if (!phone) {
                                                    phoneMessage.textContent = '';
                                                    return;
                                                }
                                                if (validatePhone(countryCode, phone)) {
                                                    showMessage('رقم الهاتف صحيح', 'success');
                                                } else {
                                                    showMessage('رقم الهاتف غير صحيح ', 'error');
                                                }
                                            }

                                            phoneInput.addEventListener('input', checkPhone);
                                            countryCodeSelect.addEventListener('change', checkPhone);
                                        });
                                    </script>
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary"> إضافة</button>
                                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">الغاء</button>
                                </div>
                            </form>
                        </div>
                        </div>
                    </div>

                <!-- End:: Add Company -->

                        <div class="card-body">
                            <div class="table-responsive">
                                <div class="mb-3">
                                    <form method="GET" action="{{ route('marketers.index') }}" class="row g-2 align-items-center justify-content-end" id="marketer-search-form">
                                        <div class="col-md-4 col-lg-3">
                                            <input type="text" name="search" value="{{ request('search') }}" class="form-control rounded-pill px-4" placeholder="ابحث باسم المسوق أو رقم الهاتف..." id="marketer-search-input" autocomplete="off" style="background-color: #f8f9fa;">
                                        </div>
                                        <div class="col-md-2 col-lg-1">
                                            <button type="submit" class="btn btn-primary btn-sm w-100 rounded-pill">
                                                <i class="bi bi-search"></i> بحث
                                            </button>
                                        </div>
                                        @if(request('search'))
                                        <div class="col-md-2 col-lg-1">
                                            <a href="{{ route('marketers.index') }}" class="btn btn-secondary btn-sm w-100 rounded-pill">
                                                <i class="bi bi-x"></i> إلغاء
                                            </a>
                                        </div>
                                        @endif
                                    </form>
                                </div>
                                <script>
                                    document.addEventListener('DOMContentLoaded', function () {
                                        let timer;
                                        const input = document.getElementById('marketer-search-input');
                                        const form = document.getElementById('marketer-search-form');
                                        input.addEventListener('input', function () {
                                            clearTimeout(timer);
                                            timer = setTimeout(function () {
                                                form.submit();
                                            }, 500); // delay for user typing
                                        });
                                    });
                                </script>
                                <table class="table text-nowrap table-bordered border-primary">
                                    <thead>
                                        <tr>
                                            <th scope="col">م</th>
                                            <th scope="col">اسم المسوّق</th>
                                            <th scope="col">الموظف</th>
                                            <th scope="col">الرقم التسويقي</th>
                                            <th scope="col">رقم الهاتف</th>
                                            <th scope="col">الموقع الرئيسي</th>
                                            <th scope="col" style="display:none;">العمولة</th>
                                            <th scope="col">عمليات</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($marketers as $marketer)
                                        <tr>
                                            <td>{{ $loop->iteration }}</td>
                                            <td>{{ $marketer->name }}</td>
                                            <td>{{ $marketer->employee->name ?? '-' }}</td>
                                            <td>{{ $marketer->marketing_code ?? '-' }}</td>
                                            <td>{{ $marketer->phone }}</td>
                                            <td>{{ $marketer->site->name ?? '-' }}</td>
                                            <td style="display:none;">{{ number_format($marketer->commissions_sum,2) }}</td>

                                            <td>
                                                <button class="btn btn-sm btn-outline-warning me-1" data-bs-toggle="modal" data-bs-target="#editMarketerModal-{{ $marketer->id }}" title="تعديل">
                                                    <i class="bi bi-pencil"></i>
                                                </button>
                                                <form action="{{ route('marketers.destroy',$marketer) }}" method="POST" class="d-inline">
                                                    @csrf @method('DELETE')
                                                    <button onclick="return confirm('هل تريد الحذف؟')" class="btn btn-sm btn-outline-danger" title="حذف"><i class="bi bi-trash"></i></button>
                                                </form>
                                            </td>
                                        </tr>

                                        <!-- Edit Marketer Modal -->
                                        <div class="modal fade" id="editMarketerModal-{{ $marketer->id }}" tabindex="-1" aria-labelledby="editMarketerModalLabel-{{ $marketer->id }}" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-centered">
                                                <div class="modal-content">
                                                    <form action="{{ route('marketers.update', $marketer) }}" method="POST">
                                                        @csrf
                                                        @method('PUT')
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="editMarketerModalLabel-{{ $marketer->id }}">تعديل المسوّق</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="إغلاق"></button>
                                                        </div>
                                                        <div class="modal-body px-4">
                                                            <div class="row gy-3">
                                                                <div class="col-xl-12 text-center mb-3" style="display: none;">
                                                                    <span class="avatar avatar-xxl avatar-rounded p-2 bg-light">
                                                                        <img src="../assets/images/company-logos/11.png" alt="" id="profile-img">
                                                                        <span class="badge rounded-pill bg-primary avatar-badge">
                                                                            <input type="file" name="photo" class="position-absolute w-100 h-100 op-0" id="profile-change">
                                                                            <i class="fe fe-camera"></i>
                                                                        </span>
                                                                    </span>
                                                                </div>
                                                                <div class="col-xl-12">
                                                                    <label for="edit-input-name-{{ $marketer->id }}" class="form-label">اسم المسوق</label>
                                                                    <input id="edit-input-name-{{ $marketer->id }}" type="text" name="name" value="{{ $marketer->name }}" placeholder="أدخل اسم المسوق" class="form-control" required>
                                                                </div>
                                                                <div class="col-xl-12">
                                                                    <label for="edit-input-marketing-number-{{ $marketer->id }}" class="form-label">الرقم التسويقي</label>
                                                                    <input id="edit-input-marketing-number-{{ $marketer->id }}" type="text" name="marketing_number" value="{{ $marketer->marketing_number }}" placeholder="أدخل الرقم التسويقي" class="form-control">
                                                                </div>
                                                                <div class="col-xl-12">
                                                                    <label for="edit-input-phone-{{ $marketer->id }}" class="form-label">رقم الهاتف</label>
                                                                    <input id="edit-input-phone-{{ $marketer->id }}" type="text" name="phone" value="{{ $marketer->phone }}" placeholder="أدخل رقم الهاتف" class="form-control" required>
                                                                </div>
                                                                @php
                                                                    $selectedEmployeeId = old('employee_id', $marketer->employee_id ?? (auth()->user()->employee_id ?? ''));
                                                                @endphp
                                                                <div class="col-xl-12">
                                                                    <label for="edit-input-employee-{{ $marketer->id }}" class="form-label">الموظف</label>
                                                                    <select id="edit-input-employee-{{ $marketer->id }}" name="employee_id" class="form-control" required>
                                                                        <option value="" disabled>اختر الموظف</option>
                                                                        @foreach($employees as $id => $emp)
                                                                            <option value="{{ $id }}" {{ $selectedEmployeeId == $id ? 'selected' : '' }}>{{ $emp }}</option>
                                                                        @endforeach
                                                                    </select>
                                                                </div>
                                                                <div class="col-xl-12">
                                                                    <label for="edit-input-location-{{ $marketer->id }}" class="form-label">الموقع</label>
                                                                    <div class="input-wrapper input-icon">
                                                                        <select id="edit-input-location-{{ $marketer->id }}" name="site_id" class="form-control" required>
                                                                            <option value="" disabled>اختر الموقع</option>
                                                                            @foreach($sites as $id => $site)
                                                                                <option value="{{ $id }}" {{ $marketer->site_id == $id ? 'selected' : '' }}>{{ $site }}</option>
                                                                            @endforeach
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="col-xl-12" id="edit-branch-dropdown-container-{{ $marketer->id }}" style="display: none;">
                                                                    <label for="edit-input-branch-{{ $marketer->id }}" class="form-label">الفرع</label>
                                                                    <div class="input-wrapper input-icon">
                                                                        <select id="edit-input-branch-{{ $marketer->id }}" name="branch_id" class="form-control">
                                                                            <option value="" disabled>اختر الفرع</option>
                                                                            <!-- الفروع ستملأ ديناميكياً -->
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <script>
                                                                    document.addEventListener('DOMContentLoaded', function () {
                                                                        const siteSelect = document.getElementById('edit-input-location-{{ $marketer->id }}');
                                                                        const branchContainer = document.getElementById('edit-branch-dropdown-container-{{ $marketer->id }}');
                                                                        const branchSelect = document.getElementById('edit-input-branch-{{ $marketer->id }}');
                                                                        const oldBranchId = @json($marketer->branch_id);

                                                                        function loadBranches(siteId, selectedBranchId = null) {
                                                                            if (!siteId) {
                                                                                branchContainer.style.display = 'none';
                                                                                branchSelect.innerHTML = '<option value="" disabled>اختر الفرع</option>';
                                                                                return;
                                                                            }
                                                                            fetch(`/api/sites/${siteId}/branches`)
                                                                                .then(response => response.json())
                                                                                .then(data => {
                                                                                    if (data.length > 0) {
                                                                                        let options = '<option value="" disabled>اختر الفرع</option>';
                                                                                        data.forEach(branch => {
                                                                                            let selected = selectedBranchId && branch.id == selectedBranchId ? 'selected' : '';
                                                                                            options += `<option value="${branch.id}" ${selected}>${branch.name}</option>`;
                                                                                        });
                                                                                        branchSelect.innerHTML = options;
                                                                                        branchContainer.style.display = '';
                                                                                    } else {
                                                                                        branchContainer.style.display = 'none';
                                                                                        branchSelect.innerHTML = '<option value="" disabled>اختر الفرع</option>';
                                                                                    }
                                                                                })
                                                                                .catch(() => {
                                                                                    branchContainer.style.display = 'none';
                                                                                    branchSelect.innerHTML = '<option value="" disabled>اختر الفرع</option>';
                                                                                });
                                                                        }

                                                                        // Initial load if marketer has a site and branch
                                                                        if (siteSelect.value) {
                                                                            loadBranches(siteSelect.value, oldBranchId);
                                                                        }

                                                                        siteSelect.addEventListener('change', function () {
                                                                            loadBranches(this.value, null);
                                                                        });
                                                                    });
                                                                </script>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="submit" class="btn btn-primary">تعديل</button>
                                                            <button type="button" class="btn btn-light" data-bs-dismiss="modal">إلغاء</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        @endforeach
                                    </tbody>
                                </table>
                             <div class="d-flex justify-content-center mt-4">
    {{ $marketers->onEachSide(1)->links('vendor.pagination.bootstrap-5') }}
</div>
                            </div>
                        </div>
  </div>
                    </div>
                </div>
            </div>
            <!-- End:: row-1 -->



        </div>

    <!-- End::app-content -->

@endsection
