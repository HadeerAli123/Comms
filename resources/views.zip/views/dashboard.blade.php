@extends('layout.app')

@section('title', 'موظفي التسويق')

@section('content')
   <!-- Start::app-content -->
        <div class="main-content app-content">
            <div class="container-fluid">

                 @include('partials.crumb')


                <!-- Start:: row-1 -->
                <div class="row">
                    <div class="col-xxl-4 col-xl-6">
                        <div class="card custom-card">
                            <div class="card-body p-4">
                                <div class="d-flex align-items-start gap-3">
                                    <div>
                                        <span class="avatar avatar-md bg-primary">
                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256"><rect width="256" height="256" fill="none"/><circle cx="128" cy="120" r="40" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16"/><rect x="40" y="40" width="176" height="176" rx="8" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16"/><path d="M57.78,216a72,72,0,0,1,140.44,0" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16"/></svg>
                                        </span>
                                    </div>
                                    <div class="d-flex align-items-start justify-content-between flex-fill flex-wrap">
                                        <div>
                                            <span class="d-block mb-1 fw-medium">عدد المواقع الرئيسية </span>
                                            <h3 class="fw-semibold mb-2">{{ $mainSitesCount }}</h3>
                                            <div class="fs-13">
                                                <span class="text-success me-1 d-inline-flex align-items-center"><i class="ti ti-arrow-up me-1"></i>2.45%</span>
                                                <span class="text-muted fs-13"  style="display:none">Increased this year</span>
                                            </div>
                                        </div>
                                        <div class="position-relative">
                                            <div id="total-employees"></div>
                                            <h5 class="fw-semibold mb-0 chart-value text-primary">40%</h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-4 col-xl-6">
                        <div class="card custom-card">
                            <div class="card-body p-4">
                                <div class="d-flex align-items-start gap-3">
                                    <div>
                                        <span class="avatar avatar-md bg-secondary">
                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256"><rect width="256" height="256" fill="none"/><circle cx="128" cy="120" r="40" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16"/><path d="M63.8,199.37a72,72,0,0,1,128.4,0" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16"/><line x1="176" y1="56" x2="224" y2="56" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16"/><line x1="200" y1="32" x2="200" y2="80" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16"/><path d="M222.67,112A95.92,95.92,0,1,1,144,33.33" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16"/></svg>
                                        </span>
                                    </div>
                                    <div class="d-flex align-items-start justify-content-between flex-fill flex-wrap">
                                        <div>
                                            <span class="d-block mb-1 fw-medium">عدد المسوّقين</span>
                                            <h3 class="fw-semibold mb-2">{{ $marketersCount }}</h3>
                                            <div class="fs-13">
                                                <span class="text-danger me-1 d-inline-flex align-items-center"><i class="ti ti-arrow-down me-1"></i>1.95%</span>
                                                <span class="text-muted fs-13" style="display:none">Decreased this year</span>
                                            </div>
                                        </div>
                                        <div class="position-relative">
                                            <div id="new-employees"></div>
                                            <h5 class="fw-semibold mb-0 chart-value text-secondary">20%</h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-4 col-xl-6">
                        <div class="card custom-card">
                            <div class="card-body p-4">
                                <div class="d-flex align-items-start gap-3">
                                    <div>
                                        <span class="avatar avatar-md bg-success">
                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256"><rect width="256" height="256" fill="none"/><circle cx="128" cy="120" r="40" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16"/><path d="M63.8,199.37a72,72,0,0,1,128.4,0" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16"/><line x1="176" y1="56" x2="224" y2="56" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16"/><path d="M218.54,96A95.93,95.93,0,1,1,144,33.33" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16"/></svg>
                                        </span>
                                    </div>
                                    <div class="d-flex align-items-start justify-content-between flex-fill flex-wrap">
                                        <div>
                                            <span class="d-block mb-1 fw-medium">إجمالي العمولات</span>
                                            <h3 class="fw-semibold mb-2">{{ number_format($totalCommissions,2) }}</h3>
                                            <div class="fs-13">
                                                <span class="text-danger me-1 d-inline-flex align-items-center"><i class="ti ti-arrow-down me-1"></i>2.5%</span>
                                                <span class="text-muted fs-13"  style="display:none">Decreased this year</span>
                                            </div>
                                        </div>
                                        <div class="position-relative">
                                            <div id="resigned-employees"></div>
                                            <h5 class="fw-semibold mb-0 chart-value text-success">50%</h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-3 col-xl-6" style="display: none;">
                        <div class="card custom-card">
                            <div class="card-body p-4">
                                <div class="d-flex align-items-start gap-3">
                                    <div>
                                        <span class="avatar avatar-md bg-info">
                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256"><rect width="256" height="256" fill="none"/><circle cx="128" cy="136" r="32" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16"/><path d="M80,192a60,60,0,0,1,96,0" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16"/><rect x="32" y="48" width="192" height="160" rx="8" transform="translate(256) rotate(90)" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16"/><line x1="96" y1="64" x2="160" y2="64" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16"/></svg>
                                        </span>
                                    </div>
                                    <div class="d-flex align-items-start justify-content-between flex-fill flex-wrap">
                                        <div>
                                            <span class="d-block mb-1 fw-medium">Employees On Leave</span>
                                            <h3 class="fw-semibold mb-2">212</h3>
                                            <div class="fs-13">
                                                <span class="text-success me-1 d-inline-flex align-items-center"><i class="ti ti-arrow-up me-1"></i>1.32%</span>
                                                <span class="text-muted fs-13">Increased this year</span>
                                            </div>
                                        </div>
                                        <div class="position-relative">
                                            <div id="employees-on-leave"></div>
                                            <h5 class="fw-semibold mb-0 chart-value text-info">60%</h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End:: row-1 -->



            </div>
        </div>
        <!-- End::app-content -->

@endsection
