@extends('layout.app')

@section('title', 'الدول')

@section('content')
<!-- Start::app-content -->
<div class="main-content app-content">
    <div class="container-fluid">

        @include('partials.crumb')

        <!-- Start:: row-1 -->
        <div class="row">
            <div class="col-xl-12">
                <div class="card custom-card">
                    <div class="card-header justify-content-between">
                        <div class="card-title">
                            الدول
                        </div>
                        <div class="d-flex flex-wrap gap-2">
                            <button class="btn btn-primary btn-sm btn-wave" data-bs-toggle="modal" data-bs-target="#addCountryModal">
                                <i class="ri-add-line me-1 fw-medium align-middle"></i> إضافة دولة جديدة
                            </button>
                        </div>
                    </div>

                    <!-- Start:: Add Country Modal -->
                    <div class="modal fade" id="addCountryModal" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <form action="{{ route('countries.store') }}" method="POST">
                                    @csrf
                                    <div class="modal-header">
                                        <h6 class="modal-title">إضافة دولة جديدة</h6>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body px-4">
                                        <div class="row gy-3">
                                            <div class="col-xl-12">
                                                <label for="country-name" class="form-label">اسم الدولة</label>
                                                <input id="country-name" type="text" name="name" placeholder="أدخل اسم الدولة" class="form-control" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-primary">إضافة</button>
                                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">الغاء</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- End:: Add Country Modal -->

                    <div class="card-body">
                  
                        <div class="table-responsive">
                            <table class="table text-nowrap table-bordered border-primary">
                                <thead>
                                    <tr>
                                        <th scope="col">م</th>
                                        <th scope="col">اسم الدولة</th>
                                        <th scope="col">عمليات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($countries as $country)
                                        <tr>
                                            <td>{{ $loop->iteration }}</td>
                                            <td>{{ $country->name }}</td>
                                            <td>
                                                <button class="btn btn-sm btn-outline-warning me-1" data-bs-toggle="modal" data-bs-target="#editCountryModal-{{ $country->id }}" title="تعديل">
                                                    <i class="bi bi-pencil"></i>
                                                </button>
                                                <form action="{{ route('countries.destroy', $country) }}" method="POST" class="d-inline">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button onclick="return confirm('هل تريد الحذف؟')" class="btn btn-sm btn-outline-danger" title="حذف">
                                                        <i class="bi bi-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>

                                        <!-- Edit Country Modal -->
                                        <div class="modal fade" id="editCountryModal-{{ $country->id }}" tabindex="-1" aria-labelledby="editCountryModalLabel-{{ $country->id }}" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-centered">
                                                <div class="modal-content">
                                                    <form action="{{ route('countries.update', $country) }}" method="POST">
                                                        @csrf
                                                        @method('PUT')
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="editCountryModalLabel-{{ $country->id }}">تعديل الدولة</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="إغلاق"></button>
                                                        </div>
                                                        <div class="modal-body px-4">
                                                            <div class="row gy-3">
                                                                <div class="col-xl-12">
                                                                    <label for="edit-country-name-{{ $country->id }}" class="form-label">اسم الدولة</label>
                                                                    <input id="edit-country-name-{{ $country->id }}" type="text" name="name" value="{{ $country->name }}" placeholder="أدخل اسم الدولة" class="form-control" required>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="submit" class="btn btn-primary">تعديل</button>
                                                            <button type="button" class="btn btn-light" data-bs-dismiss="modal">إلغاء</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- End:: Edit Country Modal -->
                                    @endforeach
                                </tbody>
                            </table>
                            <div class="d-flex justify-content-center mt-4">
                                {{ $countries->onEachSide(1)->links('vendor.pagination.bootstrap-5') }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End:: row-1 -->

    </div>
</div>
<!-- End::app-content -->
@endsection
