@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Add Country</h1>

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>@foreach ($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul>
        </div>
    @endif
    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    <form action="{{ route('countries.store') }}" method="POST">
        @csrf
        <div class="mb-3">
            <label>الاسم</label>
            <input type="text" name="name" class="form-control" required value="{{ old('name') }}">
        </div>
        <button class="btn btn-success">حفظ</button>
    </form>
</div>
@endsection
