@extends('layout.app')

@section('title', 'موظفين التسويق')

@section('content')
    <!-- Start::app-content -->
    <div class="main-content app-content">
        <div class="container-fluid">

            @include('partials.crumb')


            <!-- Start:: row-1 -->
            <div class="row">
                <div class="col-xl-12">
                    <div class="card custom-card">
                        <div class="card-header justify-content-between">
                            <div class="card-title">
                                موظفين التسويق
                            </div>

                            <div class="d-flex flex-wrap gap-2">
                                <a href="{{ route('roles.index') }}" class="btn btn-info btn-sm btn-wave">
                                    <i class="ri-group-line me-1 fw-medium align-middle"></i> مجموعات العمل
                                </a>
                                <button class="btn btn-primary btn-sm btn-wave" data-bs-toggle="modal"
                                    data-bs-target="#addMarketerModal"><i
                                        class="ri-add-line me-1 fw-medium align-middle"></i> إضافة موظف جديد</button>

                            </div>

                        </div>
                        <!-- Start:: Add Company -->
                        <div class="modal fade" id="addMarketerModal" tabindex="-1" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <form action="{{ route('marketing-employees.store') }}" method="POST">
                                        @csrf
                                        <div class="modal-header">
                                            <h6 class="modal-title">إضافة موظف تسويق جديد</h6>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body px-4">
                                            <div class="row gy-3">
                                                <div class="col-xl-12" style="display: none;">
                                                    <div class="mb-0 text-center">
                                                        <span class="avatar avatar-xxl avatar-rounded p-2 bg-light">
                                                            <img src="../assets/images/company-logos/11.png" alt=""
                                                                id="profile-img">
                                                            <span class="badge rounded-pill bg-primary avatar-badge">
                                                                <input type="file" name="photo"
                                                                    class="position-absolute w-100 h-100 op-0"
                                                                    id="profile-change">
                                                                <i class="fe fe-camera"></i>
                                                            </span>
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-xl-12">
                                                    <div class="input-wrapper input-icon">
                                                        <label for="geex-input-username" class="input-label">اسم
                                                            المستخدم</label>
                                                        <input id="geex-input-username" type="text" name="username"
                                                            placeholder="أدخل اسم المستخدم" class="form-control" required>
                                                        <i class="uil uil-user"></i>
                                                    </div>
                                                </div>
                                                <div class="col-xl-12">
                                                    <div class="input-wrapper input-icon">
                                                        <label for="geex-input-name" class="input-label">الاسم</label>
                                                        <input id="geex-input-name" type="text" name="name"
                                                            placeholder="أدخل الاسم" class="form-control" required>
                                                        <i class="uil uil-user"></i>
                                                    </div>
                                                </div>
                                                <div class="col-xl-12">
                                                    <div class="input-wrapper input-icon">
                                                        <label for="roles" class="input-label mb-2">المجموعات</label>
                                                        <select name="roles[]" id="roles" class="form-select" multiple required>
                                                            @foreach($roles as $role)
                                                                <option value="{{ $role->name }}">{{ $role->name }}</option>
                                                            @endforeach
                                                        </select>
                                                        <i class="uil uil-users-alt"></i>
                                                    </div>
                                                </div>
                                                <div class="col-xl-12">
                                                    <div class="input-wrapper input-icon">
                                                        <label for="geex-input-password" class="input-label">كلمة
                                                            المرور</label>
                                                        <input id="geex-input-password" type="password" name="password"
                                                            placeholder="أدخل كلمة المرور" class="form-control" required>
                                                        <i class="uil uil-lock"></i>
                                                    </div>
                                                </div>
                                                <div class="col-xl-12">
                                                    <div class="input-wrapper input-icon">
                                                        <label for="geex-input-password-confirmation"
                                                            class="input-label">تأكيد كلمة المرور</label>
                                                        <input id="geex-input-password-confirmation" type="password"
                                                            name="password_confirmation"
                                                            placeholder="أدخل تأكيد كلمة المرور" class="form-control"
                                                            required>
                                                        <i class="uil uil-lock"></i>
                                                    </div>
                                                </div>
                                                <div class="col-xl-12">
                                                    <div class="input-wrapper input-icon">
                                                        <label for="geex-input-email" class="input-label">البريد
                                                            الإلكتروني</label>
                                                        <input id="geex-input-email" type="email" name="email"
                                                            placeholder="أدخل البريد الإلكتروني" class="form-control"
                                                            required>
                                                        <i class="uil uil-envelope"></i>
                                                    </div>
                                                </div>
                                                <div class="col-xl-12">
                                                    <label for="geex-input-phone" class="form-label">رقم الهاتف</label>
                                                    <div class="input-wrapper input-icon position-relative">
                                                        <div class="input-group">
                                                            <span class="input-group-text p-0" style="min-width: 110px;">
                                                                <img id="selected-flag-img" src="{{ asset('assets/flags/sa.png') }}" alt="flag" style="width: 24px; height: 18px; margin-right: 5px;">
                                                                <select name="country_code" id="country-code-select" class="form-select border-0 bg-transparent px-2" style="width: 80px;" required>
                                                                    <option value="+966" selected data-flag="sa" data-flag-src="{{ asset('assets/flags/sa.png') }}">+966</option>
                                                                    <option value="+20" data-flag="eg" data-flag-src="{{ asset('assets/flags/eg.png') }}">+20</option>
                                                                    <option value="+971" data-flag="ae" data-flag-src="{{ asset('assets/flags/ae.png') }}">+971</option>
                                                                    <option value="+965" data-flag="kw" data-flag-src="{{ asset('assets/flags/kw.png') }}">+965</option>
                                                                    <option value="+964" data-flag="iq" data-flag-src="{{ asset('assets/flags/iq.png') }}">+964</option>
                                                                    <option value="+962" data-flag="jo" data-flag-src="{{ asset('assets/flags/jo.png') }}">+962</option>
                                                                    <option value="+963" data-flag="sy" data-flag-src="{{ asset('assets/flags/sy.png') }}">+963</option>
                                                                    <option value="+968" data-flag="om" data-flag-src="{{ asset('assets/flags/om.png') }}">+968</option>
                                                                    <option value="+973" data-flag="bh" data-flag-src="{{ asset('assets/flags/bh.png') }}">+973</option>
                                                                    <option value="+974" data-flag="qa" data-flag-src="{{ asset('assets/flags/qa.png') }}">+974</option>
                                                                </select>
                                                            </span>
                                                            <input id="geex-input-phone" type="text" name="phone" placeholder="أدخل رقم الهاتف" class="form-control" required>
                                                            <span class="input-group-text"><i class="uil uil-phone"></i></span>
                                                        </div>
                                                        <span id="phone-validity-msg" class="mt-2 d-block" style="font-size: 0.95rem;"></span>
                                                    </div>
                                                </div>
                                                <script>
                                                    document.addEventListener('DOMContentLoaded', function () {
                                                        const select = document.getElementById('country-code-select');
                                                        const flagImg = document.getElementById('selected-flag-img');
                                                        const phoneInput = document.getElementById('geex-input-phone');
                                                        const msgSpan = document.getElementById('phone-validity-msg');

                                                        function updateFlag() {
                                                            const selectedOption = select.options[select.selectedIndex];
                                                            const flagSrc = selectedOption.getAttribute('data-flag-src');
                                                            if(flagSrc) {
                                                                flagImg.src = flagSrc;
                                                            }
                                                        }

                                                        function validatePhone() {
                                                            const countryCode = select.value;
                                                            const phone = phoneInput.value.trim();
                                                            let valid = false;
                                                            let regex;
                                                            // Basic regex for each country (can be improved)
                                                            switch(countryCode) {
                                                                case '+966': // Saudi Arabia
                                                                    regex = /^5\d{8}$/;
                                                                    break;
                                                                case '+20': // Egypt
                                                                    regex = /^1\d{9}$/;
                                                                    break;
                                                                case '+971': // UAE
                                                                    regex = /^5\d{8}$/;
                                                                    break;
                                                                case '+965': // Kuwait
                                                                    regex = /^[569]\d{7}$/;
                                                                    break;
                                                                case '+964': // Iraq
                                                                    regex = /^7\d{9}$/;
                                                                    break;
                                                                case '+962': // Jordan
                                                                    regex = /^7\d{8}$/;
                                                                    break;
                                                                case '+963': // Syria
                                                                    regex = /^9\d{8}$/;
                                                                    break;
                                                                case '+968': // Oman
                                                                    regex = /^9\d{7}$/;
                                                                    break;
                                                                case '+973': // Bahrain
                                                                    regex = /^3\d{7}$/;
                                                                    break;
                                                                case '+974': // Qatar
                                                                    regex = /^3\d{7}$/;
                                                                    break;
                                                                default:
                                                                    regex = /^\d+$/;
                                                            }
                                                            if (regex.test(phone)) {
                                                                valid = true;
                                                            }
                                                            if (phone.length === 0) {
                                                                msgSpan.textContent = '';
                                                                msgSpan.classList.remove('text-success', 'text-danger');
                                                            } else if (valid) {
                                                                msgSpan.textContent = 'الرقم صحيح';
                                                                msgSpan.classList.add('text-success');
                                                                msgSpan.classList.remove('text-danger');
                                                            } else {
                                                                msgSpan.textContent = 'الرقم غير صحيح';
                                                                msgSpan.classList.add('text-danger');
                                                                msgSpan.classList.remove('text-success');
                                                            }
                                                        }

                                                        select.addEventListener('change', function() {
                                                            updateFlag();
                                                            validatePhone();
                                                        });
                                                        phoneInput.addEventListener('input', validatePhone);

                                                        updateFlag();
                                                        validatePhone();
                                                    });
                                                </script>
                                                <div class="col-xl-12">
                                                    <div class="row">
                                                        <div class="col-xl-6">
                                                            <div class="input-wrapper input-icon">
                                                                <label for="geex-input-percentage" class="input-label">النسبة</label>
                                                                <input id="geex-input-percentage" type="number" name="percentage"
                                                                    placeholder="أدخل النسبة" class="form-control" min="0"
                                                                    max="100" step="0.01" required>
                                                                <i class="uil uil-percentage"></i>
                                                            </div>
                                                        </div>
                                                        <div class="col-xl-6">
                                                            <div class="input-wrapper input-icon">
                                                                <label for="geex-input-table-commission" class="input-label">مبلغ عمولة الطاولة</label>
                                                                <input id="geex-input-table-commission" type="number" name="table_commission"
                                                                    placeholder="أدخل المبلغ  " class="form-control" min="0" step="0.01" required>
                                                                <i class="uil uil-money-bill"></i>
                                                            </div>
                                                            <span class="mt-2 text-danger" >
                                                                عمولة الموظف على الطاولة
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>


                                                @if ($errors->any())
                                                    <div class="col-xl-12">
                                                        <div class="alert alert-danger mt-3">
                                                            <ul class="mb-0">
                                                                @foreach ($errors->all() as $msg)
                                                                    <li>{{ $msg }}</li>
                                                                @endforeach
                                                            </ul>
                                                        </div>
                                                    </div>
                                                @endif

                                            </div>
                                        </div>
                                        <div class="modal-footer">

                                            <button type="submit" class="btn btn-primary"> إضافة</button>
                                            <button type="button" class="btn btn-light"
                                                data-bs-dismiss="modal">الغاء</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <!-- End:: Add Company -->

                        <div class="card-body">
                            <div class="table-responsive">
                            <form method="GET" action="{{ route('marketing-employees.index') }}" class="row g-2 align-items-center justify-content-end mb-3" id="employee-search-form">
                                <div class="col-md-4 col-lg-3">
                                    <input type="text" name="search" value="{{ request('search') }}" class="form-control rounded-pill px-4" placeholder="ابحث باسم الموظف أو اسم المستخدم..." id="employee-search-input" autocomplete="off" style="background-color: #f8f9fa;">
                                </div>
                                <div class="col-md-2 col-lg-1">
                                    <button type="submit" class="btn btn-primary btn-sm w-100 rounded-pill">
                                        <i class="bi bi-search"></i> بحث
                                    </button>
                                </div>
                                @if(request('search'))
                                <div class="col-md-2 col-lg-1">
                                    <a href="{{ route('marketing-employees.index') }}" class="btn btn-secondary btn-sm w-100 rounded-pill">
                                        <i class="bi bi-x"></i> إلغاء
                                    </a>
                                </div>
                                @endif
                            </form>
                            <script>
                                document.addEventListener('DOMContentLoaded', function () {
                                    let timer;
                                    const input = document.getElementById('employee-search-input');
                                    const form = document.getElementById('employee-search-form');
                                    if (input && form) {
                                        input.addEventListener('input', function () {
                                            clearTimeout(timer);
                                            timer = setTimeout(function () {
                                                form.submit();
                                            }, 500);
                                        });
                                    }
                                });
                            </script>
                                <table class="table text-nowrap table-bordered border-primary">
                                    <thead>
                                        <tr>
                                            <th scope="col">م</th>
                                            <th>اسم المستخدم</th>
                                            <th>اسم موظف التسويق</th>
                                            <th>المجموعات</th>
                                            <th>الرقم التسويقي</th>
                                            <th>عدد المسوقين</th>
                                            <th>إجمالي عمولات المسوقين</th>
                                            <th>مبلغ العمولة  </th>
                                            <th>البريد الإلكتروني</th>
                                            <th>النسبة</th>
                                            <th>عمليات</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($employees as $emp)
                                            <tr>
                                                <td>{{ $loop->iteration }}</td>
                                                <td>{{ $emp->username }}</td>
                                                <td>{{ $emp->name }}</td>
                                                <td>
                                                    @foreach($emp->roles as $role)
                                                        <span class="badge bg-info">{{ __("roles." . $role->name) ?? $role->name }}</span>
                                                    @endforeach
                                                </td>
                                                <td>{{ $emp->marketing_code ?? '-' }}</td>
                                                <td>
                                                    <a href="{{ route('marketers.index', ['employee_id' => $emp->id]) }}">
                                                        {{ $emp->marketers_count ?? 0 }}
                                                    </a>
                                                </td>
                                                <td>
                                                    <a href="{{ route('marketers.index', ['employee_id' => $emp->id]) }}">
                                                        {{ number_format($emp->commissions_sum_commission_amount ?? 0, 2) }}
                                                    </a>
                                                </td>
                                                <td>
                                                    {{-- مبلغ العمولة بعد النسبة --}}
                                                    @php
                                                        $total = $emp->commissions_sum_commission_amount ?? 0;
                                                        $percentage = $emp->prec ?? 0;
                                                        $after_percentage = $total * ($percentage / 100);
                                                    @endphp
                                                    {{ number_format($after_percentage, 2) }}
                                                </td>
                                                <td>{{ $emp->email }}</td>
                                                <td>{{ $emp->prec }}%</td>
                                                <td>
                                                    <button class="btn btn-sm btn-outline-warning me-1"
                                                        data-bs-toggle="modal"
                                                        data-bs-target="#editEmployeeModal-{{ $emp->id }}"
                                                        title="تعديل">
                                                        <i class="bi bi-pencil"></i>
                                                    </button>

                                                    <form action="{{ route('marketing-employees.destroy', $emp) }}"
                                                        method="POST" class="d-inline">
                                                        @csrf @method('DELETE')
                                                        <button class="btn btn-sm btn-outline-danger"
                                                            onclick="return confirm('هل تريد الحذف؟')" title="حذف">
                                                            <i class="bi bi-trash"></i>
                                                        </button>
                                                    </form>
                                                </td>
                                                <!-- Modal for editing employee -->
                                                <div class="modal fade" id="editEmployeeModal-{{ $emp->id }}"
                                                    tabindex="-1"
                                                    aria-labelledby="editEmployeeLabel-{{ $emp->id }}"
                                                    aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content geex-content__form">
                                                            <form action="{{ route('marketing-employees.update', $emp) }}"
                                                                method="POST">
                                                                @csrf
                                                                @method('PUT')
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title" id="editEmployeeLabel-{{ $emp->id }}">تعديل بيانات موظف التسويق</h5>
                                                                    <button type="button" class="btn-close ms-auto"
                                                                        data-bs-dismiss="modal" aria-label="إغلاق"></button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <div class="geex-content__form__single__box">
                                                                        <div class="input-wrapper input-icon">
                                                                            <label class="input-label">اسم المستخدم</label>
                                                                            <input type="text" name="username"
                                                                                value="{{ $emp->username }}"
                                                                                class="form-control" required>
                                                                            <i class="uil uil-user"></i>
                                                                        </div>
                                                                        <div class="input-wrapper input-icon">
                                                                            <label class="input-label">الاسم</label>
                                                                            <input type="text" name="name"
                                                                                value="{{ $emp->name }}"
                                                                                class="form-control" required>
                                                                            <i class="uil uil-user"></i>
                                                                        </div>
                                                                    </div>
                                                                    <div class="mb-3">
                                                                        <label for="roles-edit-{{ $emp->id }}" class="form-label">المجموعات</label>
                                                                        <select name="roles[]" id="roles-edit-{{ $emp->id }}" class="form-select" multiple>
                                                                            @foreach($roles as $role)
                                                                                <option value="{{ $role->name }}"
                                                                                    {{ $emp->roles->contains('name', $role->name) ? 'selected' : '' }}>
                                                                                    {{ $role->name }}
                                                                                </option>
                                                                            @endforeach
                                                                        </select>
                                                                    </div>
                                                                    <div class="geex-content__form__single__box">
                                                                        <div class="input-wrapper input-icon">
                                                                            <label class="input-label">كلمة المرور الجديدة
                                                                                (اختياري)</label>
                                                                            <input type="password" name="password"
                                                                                class="form-control"
                                                                                placeholder="أدخل كلمة المرور الجديدة">
                                                                            <i class="uil uil-lock"></i>
                                                                        </div>
                                                                        <div class="input-wrapper input-icon">
                                                                            <label class="input-label">تأكيد كلمة
                                                                                المرور</label>
                                                                            <input type="password"
                                                                                name="password_confirmation"
                                                                                class="form-control"
                                                                                placeholder="أدخل تأكيد كلمة المرور">
                                                                            <i class="uil uil-lock"></i>
                                                                        </div>
                                                                        <div class="input-wrapper input-icon">
                                                                            <label class="input-label">البريد
                                                                                الإلكتروني</label>
                                                                            <input type="email" name="email"
                                                                                value="{{ $emp->email }}"
                                                                                class="form-control" required>
                                                                            <i class="uil uil-envelope"></i>
                                                                        </div>
                                                                        <div class="input-wrapper input-icon">
                                                                            <label class="form-label">رقم الهاتف</label>
                                                                            <div class="input-group">
                                                                                <span class="input-group-text p-0" style="min-width: 110px;">
                                                                                    <img id="selected-flag-img-edit-{{ $emp->id }}" src="{{ asset('assets/flags/' . ($emp->country_flag ?? 'sa') . '.png') }}" alt="flag" style="width: 24px; height: 18px; margin-right: 5px;">
                                                                                    <select name="country_code" id="country-code-select-edit-{{ $emp->id }}" class="form-select border-0 bg-transparent px-2" style="width: 80px;" required>
                                                                                        <option value="+966" {{ $emp->country_code == '+966' ? 'selected' : '' }} data-flag="sa" data-flag-src="{{ asset('assets/flags/sa.png') }}">+966</option>
                                                                                        <option value="+20" {{ $emp->country_code == '+20' ? 'selected' : '' }} data-flag="eg" data-flag-src="{{ asset('assets/flags/eg.png') }}">+20</option>
                                                                                        <option value="+971" {{ $emp->country_code == '+971' ? 'selected' : '' }} data-flag="ae" data-flag-src="{{ asset('assets/flags/ae.png') }}">+971</option>
                                                                                        <option value="+965" {{ $emp->country_code == '+965' ? 'selected' : '' }} data-flag="kw" data-flag-src="{{ asset('assets/flags/kw.png') }}">+965</option>
                                                                                        <option value="+964" {{ $emp->country_code == '+964' ? 'selected' : '' }} data-flag="iq" data-flag-src="{{ asset('assets/flags/iq.png') }}">+964</option>
                                                                                        <option value="+962" {{ $emp->country_code == '+962' ? 'selected' : '' }} data-flag="jo" data-flag-src="{{ asset('assets/flags/jo.png') }}">+962</option>
                                                                                        <option value="+963" {{ $emp->country_code == '+963' ? 'selected' : '' }} data-flag="sy" data-flag-src="{{ asset('assets/flags/sy.png') }}">+963</option>
                                                                                        <option value="+968" {{ $emp->country_code == '+968' ? 'selected' : '' }} data-flag="om" data-flag-src="{{ asset('assets/flags/om.png') }}">+968</option>
                                                                                        <option value="+973" {{ $emp->country_code == '+973' ? 'selected' : '' }} data-flag="bh" data-flag-src="{{ asset('assets/flags/bh.png') }}">+973</option>
                                                                                        <option value="+974" {{ $emp->country_code == '+974' ? 'selected' : '' }} data-flag="qa" data-flag-src="{{ asset('assets/flags/qa.png') }}">+974</option>
                                                                                    </select>
                                                                                </span>
                                                                                <input type="text" name="phone" value="{{ $emp->phone }}" placeholder="أدخل رقم الهاتف" class="form-control" required>
                                                                                <span class="input-group-text"><i class="uil uil-phone"></i></span>
                                                                            </div>
                                                                        </div>
                                                                        <script>
                                                                            document.addEventListener('DOMContentLoaded', function () {
                                                                                const select = document.getElementById('country-code-select-edit-{{ $emp->id }}');
                                                                                const flagImg = document.getElementById('selected-flag-img-edit-{{ $emp->id }}');
                                                                                function updateFlag() {
                                                                                    const selectedOption = select.options[select.selectedIndex];
                                                                                    const flagSrc = selectedOption.getAttribute('data-flag-src');
                                                                                    if(flagSrc) {
                                                                                        flagImg.src = flagSrc;
                                                                                    }
                                                                                }
                                                                                select.addEventListener('change', updateFlag);
                                                                                updateFlag();
                                                                            });
                                                                        </script>
                                                                        <div class="row">
                                                                            <div class="col-xl-6">
                                                                                <div class="input-wrapper input-icon">
                                                                                    <label for="geex-input-percentage-edit-{{ $emp->id }}" class="input-label">النسبة</label>
                                                                                    <input id="geex-input-percentage-edit-{{ $emp->id }}" type="number" name="percentage"
                                                                                        value="{{ $emp->prec }}"
                                                                                        class="form-control" min="0"
                                                                                        max="100" step="0.01"
                                                                                        placeholder="أدخل النسبة" required>
                                                                                    <i class="uil uil-percentage"></i>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-xl-6">
                                                                                <div class="input-wrapper input-icon">
                                                                                    <label for="geex-input-table-commission-edit-{{ $emp->id }}" class="input-label">مبلغ عمولة الطاولة</label>
                                                                                    <input id="geex-input-table-commission-edit-{{ $emp->id }}" type="number" name="table_commission"
                                                                                        value="{{ $emp->table_commission }}"
                                                                                        placeholder="أدخل المبلغ" class="form-control" min="0" step="0.01" required>
                                                                                    <i class="uil uil-money-bill"></i>
                                                                                </div>
                                                                                <span class="mt-2 text-danger" style="font-size: 0.95rem;">
                                                                                    عمولة الموظف على الطاولة
                                                                                </span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    @if ($errors->any())
                                                                        <div class="alert alert-danger mt-3">
                                                                            <ul class="mb-0">
                                                                                @foreach ($errors->all() as $msg)
                                                                                    <li>{{ $msg }}</li>
                                                                                @endforeach
                                                                            </ul>
                                                                        </div>
                                                                    @endif
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="submit" class="btn btn-primary">
                                                                        <i class="uil-save me-1"></i> حفظ التعديلات
                                                                    </button>
                                                                    <button type="button" class="btn btn-secondary"
                                                                        data-bs-dismiss="modal">إلغاء</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </tr>
                                        @endforeach

                                    </tbody>
                                </table>
                                <div class="d-flex justify-content-center mt-4">
    {{ $employees->onEachSide(1)->links('vendor.pagination.bootstrap-5') }}
</div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <!-- End:: row-1 -->



        </div>
    </div>
    <!-- End::app-content -->

@endsection
