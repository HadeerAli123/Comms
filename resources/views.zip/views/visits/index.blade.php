@extends('layout.app')

@section('title', 'الزيارات')

@section('content')
<div class="main-content app-content">
    <div class="container-fluid">
        @include('partials.crumb')

        <div class="row">
            <div class="col-xl-12">
                <div class="card custom-card">
                    <div class="card-header justify-content-between">
                        <div class="card-title">
                            الزيارات
                        </div>

                    </div>
                    <div class="card-body">
                        <div class="row">
                        <ul class="nav nav-pills mb-3" id="visits-tabs" role="tablist">

                                <li class="nav-item col-md-2" role="presentation">
                                    <button class="nav-link active rounded-pill px-4 py-2 fw-bold w-100 border border-primary" id="all-tab" data-bs-toggle="pill" data-bs-target="#all" type="button" role="tab" aria-controls="all" aria-selected="true">
                                        الكل ({{ $visits_all->count() }})
                                    </button>
                                </li>
                                <li class="nav-item col-md-2" role="presentation">
                                    <button class="nav-link rounded-pill px-4 py-2 fw-bold w-100 border border-primary" id="done-tab" data-bs-toggle="pill" data-bs-target="#done" type="button" role="tab" aria-controls="done" aria-selected="false">
                                        تم الإعلان ({{ $visits_done->count() }})
                                    </button>
                                </li>
                                <li class="nav-item col-md-2" role="presentation">
                                    <button class="nav-link rounded-pill px-4 py-2 fw-bold w-100 border border-primary" id="pending-tab" data-bs-toggle="pill" data-bs-target="#pending" type="button" role="tab" aria-controls="pending" aria-selected="false">
                                        لم يتم الإعلان ({{ $visits_pending->count() }})
                                    </button>
                                </li>
                                <li class="nav-item col-md-2" role="presentation">
                                    <button class="nav-link rounded-pill px-4 py-2 fw-bold w-100 border border-primary" id="not-specified-tab" data-bs-toggle="pill" data-bs-target="#not-specified" type="button" role="tab" aria-controls="not-specified" aria-selected="false">
                                        لم يتم التحديد ({{ $visits_not_specified->count() }})
                                    </button>
                                </li>

                        </ul>
   </div>
                        <div class="tab-content mt-3" id="visits-tabs-content">
                            <div class="tab-pane fade show active" id="all" role="tabpanel" aria-labelledby="all-tab">
                                @include('visits.partials.table', ['visits' => $visits_all])
                            </div>
                            <div class="tab-pane fade" id="done" role="tabpanel" aria-labelledby="done-tab">
                                @include('visits.partials.table', ['visits' => $visits_done])
                            </div>
                            <div class="tab-pane fade" id="pending" role="tabpanel" aria-labelledby="pending-tab">
                                @include('visits.partials.table', ['visits' => $visits_pending])
                            </div>

                            <div class="tab-pane fade" id="not-specified" role="tabpanel" aria-labelledby="not-specified-tab">
                                @include('visits.partials.table', ['visits' => $visits_not_specified])
                            </div>
                            
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
