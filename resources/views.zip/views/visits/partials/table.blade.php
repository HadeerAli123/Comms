<table class="table table-bordered">
    <thead>
        <tr>
            <th>#</th>
            <th>المشهور</th>
            <th>المبلغ</th>
            <th>عدد الأشخاص</th>
            <th>الحالة</th>
            <th>التقييم</th>
            <th>تاريخ الإضافة</th>
            <th>بواسطة</th>
            <th>إجراءات</th>
        </tr>
    </thead>
    <tbody>
        @forelse($visits as $visit)
        <tr>
            <td>{{ $loop->iteration }}</td>
            <td>{{ $visit->influencer->name }}</td>
            <td>{{ number_format($visit->amount, 2) }}</td>
                        <td>{{ $visit->people_count ?? '-' }}</td> <!-- عرض عدد الأشخاص -->

            <td>
                @if($visit->is_announced == 0)
                    <span class="badge bg-secondary">لم يتم التحديد</span>
                @elseif($visit->is_announced == 1)
                    <span class="badge bg-success mb-2">تم الإعلان</span>
                    <div class="mt-2 d-flex flex-column align-items-start gap-2">
                        <button type="button" class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#detailsModal{{ $visit->id }}">
                          اضغط للمشاهدة
                        </button>

                        <!-- Details Modal -->
                        <div class="modal fade" id="detailsModal{{ $visit->id }}" tabindex="-1" aria-labelledby="detailsModalLabel{{ $visit->id }}" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="detailsModalLabel{{ $visit->id }}">تفاصيل الإعلان</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="إغلاق"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="d-flex flex-column gap-3">
                                            @if($visit->media)
                                                @php
                                                    $mediaUrl = asset('storage/' . $visit->media);
                                                    $mediaExt = pathinfo($visit->media, PATHINFO_EXTENSION);
                                                @endphp
                                                <div>
                                                    @if(in_array(strtolower($mediaExt), ['jpg','jpeg','png','gif','webp']))
                                                        <a href="{{ $mediaUrl }}" target="_blank" class="d-inline-block">
                                                            <img src="{{ $mediaUrl }}" alt="مرفق الإعلان" class="rounded shadow-sm border" style="max-width: 150px; max-height: 150px;">
                                                        </a>
                                                    @elseif(in_array(strtolower($mediaExt), ['mp4','webm','ogg']))
                                                        <a href="{{ $mediaUrl }}" target="_blank" class="d-inline-block">
                                                            <video src="{{ $mediaUrl }}" class="rounded shadow-sm border" style="max-width: 150px; max-height: 150px;" controls muted></video>
                                                        </a>
                                                    @else
                                                        <a href="{{ $mediaUrl }}" target="_blank" class="btn btn-sm btn-outline-primary d-flex align-items-center">
                                                            <i class="bi bi-file-earmark me-1"></i> عرض الملف المرفق
                                                        </a>
                                                    @endif
                                                </div>
                                            @endif

                                            @if($visit->accept_notes)
                                                <div>
                                                    <span class="badge bg-light text-dark border px-3 py-2 fs-6">
                                                        <strong>ملاحظة:</strong> {{ $visit->accept_notes }}
                                                    </span>
                                                </div>
                                            @endif

                                            @if($visit->rating)
                                                <div>
                                                    <span class="badge bg-warning text-dark px-3 py-2 fs-6">
                                                        <strong>التقييم:</strong> {{ $visit->rating }}
                                                    </span>
                                                </div>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                @elseif($visit->is_announced == 2)
                    <span class="badge bg-danger">لم يتم الإعلان</span>
                @endif
            </td>
                 <td>
                @if($visit->is_announced == 1)
                    <span class="badge bg-warning text-dark px-3 py-2 fs-6">
                        {{ $visit->rating ?? '-' }}
                    </span>
                @else
                    -
                @endif
            </td>
            <td>{{ $visit->created_at->format('Y-m-d H:i') }}</td>
            <td>
                {{ $visit->user->name ?? '-' }}
            </td>
            <td>
                @if($visit->is_announced== 0)
                    <!-- Trigger Modal Buttons -->
                    <button type="button" class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#announceModal{{ $visit->id }}">
                        تم الإعلان
                    </button>
                    <button type="submit" name="is_announced" value="2" class="btn btn-sm btn-danger" form="notAnnouncedForm{{ $visit->id }}">
                        لم يتم الإعلان
                    </button>

                    <!-- Not Announced Form (hidden) -->
                    <form id="notAnnouncedForm{{ $visit->id }}" action="{{ route('visits.toggleStatus', $visit) }}" method="POST" class="d-inline">
                        @csrf
                        @method('PATCH')
                    </form>

                    <!-- Announce Modal -->
                    <div class="modal fade" id="announceModal{{ $visit->id }}" tabindex="-1" aria-labelledby="announceModalLabel{{ $visit->id }}" aria-hidden="true">
                        <div class="modal-dialog">
                            <form action="{{ route('visits.toggleStatus', $visit) }}" method="POST" enctype="multipart/form-data">
                                @csrf
                                @method('PATCH')
                                <input type="hidden" name="is_announced" value="1">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="announceModalLabel{{ $visit->id }}">تقييم الإعلان</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="إغلاق"></button>
                                    </div>
                                    <div class="modal-body">
                                        <!-- Rating Stars -->
                                        <div class="mb-3">
                                            <label class="form-label">التقييم ( من 1 إلى 10):</label>
                                            <div class="d-flex flex-row gap-1 flex-wrap">
                                                @for($i = 1; $i <= 10; $i++)
                                                    <input type="radio" class="btn-check" name="rating" id="star{{ $visit->id }}{{ $i }}" value="{{ $i }}" autocomplete="off">
                                                    <label class="btn btn-outline-warning" for="star{{ $visit->id }}{{ $i }}">{{ $i }}</label>
                                                @endfor
                                            </div>
                                        </div>
                                        <!-- Note -->
                                        <div class="mb-3">
                                            <label for="accept_notes{{ $visit->id }}" class="form-label">ملاحظة <span class="text-danger">*</span>:</label>
                                            <textarea class="form-control" name="accept_notes" id="accept_notes{{ $visit->id }}" rows="2" required></textarea>
                                        </div>
                                        <!-- Screenshot/Video Upload -->
                                        <div class="mb-3">
                                            <label class="form-label">التقاط صورة أو فيديو من الكاميرا:</label>
                                            <input type="file" class="form-control" name="media" accept="image/*,video/*" capture="environment">
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-success">تأكيد الإعلان</button>
                                       <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>

                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                @elseif($visit->is_announced == 1)
                    <span class="badge bg-success">
                        تم الإعلان
                    </span>
                @elseif($visit->is_announced == 2)
                    <span class="badge bg-danger">
                        لم يتم الإعلان
                    </span>
                @endif
            </td>
        </tr>
        @empty
        <tr>
            <td colspan="7" class="text-center">لا توجد بيانات</td>
        </tr>
        @endforelse
    </tbody>
</table>
