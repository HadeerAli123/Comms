<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>403 | غير مسموح</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-gray-100 to-gray-300 min-h-screen flex items-center justify-center">
    <div class="bg-white shadow-xl rounded-2xl px-10 py-12 max-w-md w-full text-center">
        <div class="flex flex-col items-center">
            <div class="bg-red-100 rounded-full p-6 mb-4">
                <svg class="w-16 h-16 text-red-600" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M18.364 5.636l-12.728 12.728M5.636 5.636l12.728 12.728"/>
                </svg>
            </div>
            <h1 class="text-6xl font-extrabold text-red-600 mb-2"></h1>
            <h2 class="text-xl font-bold text-gray-800 mb-2">غير مسموح</h2>
            <p class="text-gray-600 mb-6">عذراً، لا تملك الصلاحية للدخول على هذه الصفحة.</p>
        </div>
        <div class="flex justify-center gap-4">
            <a href="{{ url()->previous() }}"
               class="px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition flex items-center gap-2">
                <span>🔙</span> رجوع
            </a>
            <a href="{{ url('/dashboard') }}"
               class="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition flex items-center gap-2">
                <span>🏠</span> الرئيسية
            </a>
        </div>
    </div>
</body>
</html>
