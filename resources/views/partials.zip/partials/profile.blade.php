<ul class="header-content-right">
    <!-- ... -->
    <li class="header-element country-selector dropdown">
        <!-- ... -->
        <ul class="main-header-dropdown dropdown-menu dropdown-menu-end" data-popper-placement="none">
            <li>
                <div class="py-2 px-3">
                    <input class="form-control form-control-sm" type="text" placeholder="Search Here"
                        aria-label=".form-control-sm example">
                </div>
            </li>
            <li>
                <a class="dropdown-item d-flex align-items-center justify-content-between"
                    href="javascript:void(0);">
                    <div class="d-flex align-items-center">
                        <span class="avatar avatar-rounded avatar-xs lh-1 me-2">
                            <img src="{{ asset('assets/images/flags/us_flag.jpg') }}" alt="img">
                        </span>
                        English
                    </div>
                    <span class="text-muted fs-12">(US)</span>
                </a>
            </li>
            <li>
                <a class="dropdown-item d-flex align-items-center justify-content-between"
                    href="javascript:void(0);">
                    <div class="d-flex align-items-center">
                        <span class="avatar avatar-rounded avatar-xs lh-1 me-2">
                            <img src="{{ asset('assets/images/flags/spain_flag.jpg') }}" alt="img">
                        </span>
                        español
                    </div>
                    <span class="text-muted fs-12">(ES)</span>
                </a>
            </li>
            <li>
                <a class="dropdown-item d-flex align-items-center justify-content-between"
                    href="javascript:void(0);">
                    <div class="d-flex align-items-center">
                        <span class="avatar avatar-rounded avatar-xs lh-1 me-2">
                            <img src="{{ asset('assets/images/flags/french_flag.jpg') }}" alt="img">
                        </span>
                        français
                    </div>
                    <span class="text-muted fs-12">(FR)</span>
                </a>
            </li>
            <li>
                <a class="dropdown-item d-flex align-items-center justify-content-between"
                    href="javascript:void(0);">
                    <div class="d-flex align-items-center">
                        <span class="avatar avatar-rounded avatar-xs lh-1 me-2">
                            <img src="{{ asset('assets/images/flags/uae_flag.jpg') }}" alt="img">
                        </span>
                        عربي
                    </div>
                    <span class="text-muted fs-12">(AE)</span>
                </a>
            </li>
            <li>
                <a class="dropdown-item d-flex align-items-center justify-content-between"
                    href="javascript:void(0);">
                    <div class="d-flex align-items-center">
                        <span class="avatar avatar-rounded avatar-xs lh-1 me-2">
                            <img src="{{ asset('assets/images/flags/germany_flag.jpg') }}" alt="img">
                        </span>
                        DE
                    </div>
                    <span class="text-muted fs-12">(US)</span>
                </a>
            </li>
            <li>
                <a class="dropdown-item d-flex align-items-center justify-content-between"
                    href="javascript:void(0);">
                    <div class="d-flex align-items-center">
                        <span class="avatar avatar-rounded avatar-xs lh-1 me-2">
                            <img src="{{ asset('assets/images/flags/china_flag.jpg') }}" alt="img">
                        </span>
                        中国人
                    </div>
                    <span class="text-muted fs-12">(CN)</span>
                </a>
            </li>
        </ul>
    </li>
    <!-- ... -->
    <li class="header-element cart-dropdown dropdown">
        <!-- ... -->
        <div class="main-header-dropdown dropdown-menu dropdown-menu-end" data-popper-placement="none">
            <!-- ... -->
            <ul class="list-unstyled mb-0" id="header-cart-items-scroll">
                <li class="dropdown-item">
                    <div class="cart-dropdown-item">
                        <div class="d-flex align-items-center  gap-3 mb-2">
                            <div class="lh-1">
                                <span class="avatar avatar-xl p-1 bg-primary-transparent">
                                    <img src="{{ asset('assets/images/ecommerce/png/1.png') }}" alt="img">
                                </span>
                            </div>
                            <!-- ... -->
                        </div>
                        <!-- ... -->
                    </div>
                </li>
                <li class="dropdown-item">
                    <div class="cart-dropdown-item">
                        <div class="d-flex align-items-center  gap-3 mb-2">
                            <div class="lh-1">
                                <span class="avatar avatar-xl p-1 bg-secondary-transparent">
                                    <img src="{{ asset('assets/images/ecommerce/png/14.png') }}" alt="img">
                                </span>
                            </div>
                            <!-- ... -->
                        </div>
                        <!-- ... -->
                    </div>
                </li>
                <li class="dropdown-item">
                    <div class="cart-dropdown-item">
                        <div class="d-flex align-items-center  gap-3 mb-2">
                            <div class="lh-1">
                                <span class="avatar avatar-xl p-1 bg-success-transparent">
                                    <img src="{{ asset('assets/images/ecommerce/png/33.png') }}" alt="img">
                                </span>
                            </div>
                            <!-- ... -->
                        </div>
                        <!-- ... -->
                    </div>
                </li>
                <li class="dropdown-item">
                    <div class="cart-dropdown-item">
                        <div class="d-flex align-items-center  gap-3 mb-2">
                            <div class="lh-1">
                                <span class="avatar avatar-xl p-1 bg-warning-transparent">
                                    <img src="{{ asset('assets/images/ecommerce/png/34.png') }}" alt="img">
                                </span>
                            </div>
                            <!-- ... -->
                        </div>
                        <!-- ... -->
                    </div>
                </li>
                <li class="dropdown-item">
                    <div class="cart-dropdown-item">
                        <div class="d-flex align-items-center  gap-3 mb-2">
                            <div class="lh-1">
                                <span class="avatar avatar-xl p-1 bg-pink-transparent">
                                    <img src="{{ asset('assets/images/ecommerce/png/31.png') }}" alt="img">
                                </span>
                            </div>
                            <!-- ... -->
                        </div>
                        <!-- ... -->
                    </div>
                </li>
            </ul>
            <!-- ... -->
        </div>
        <!-- ... -->
    </li>
    <!-- ... -->
    <li class="header-element notifications-dropdown d-xl-block d-none dropdown">
        <!-- ... -->
        <div class="main-header-dropdown dropdown-menu dropdown-menu-end" data-popper-placement="none">
            <!-- ... -->
            <div class="tab-content">
                <div class="tab-pane show active p-0 border-0" id="activity-tab-pane" role="tabpanel"
                    aria-labelledby="activity-tab" tabindex="0">
                    <ul class="list-unstyled mb-0" id="header-notification-scroll1">
                        <li class="dropdown-item">
                            <div class="d-flex align-items-start">
                                <div class="pe-2 lh-1"> <span
                                        class="avatar avatar-md avatar-rounded svg-white">
                                        <img src="{{ asset('assets/images/faces/2.jpg') }}" alt="img"> </span>
                                </div>
                                <!-- ... -->
                            </div>
                        </li>
                        <li class="dropdown-item">
                            <div class="d-flex align-items-start">
                                <div class="pe-2 lh-1"> <span
                                        class="avatar avatar-md avatar-rounded svg-white">
                                        <img src="{{ asset('assets/images/faces/6.jpg') }}" alt="img"> </span>
                                </div>
                                <!-- ... -->
                            </div>
                        </li>
                        <li class="dropdown-item">
                            <div class="d-flex align-items-start">
                                <div class="pe-2 lh-1"> <span
                                        class="avatar avatar-md avatar-rounded svg-white">
                                        <img src="{{ asset('assets/images/faces/14.jpg') }}" alt="img"> </span>
                                </div>
                                <!-- ... -->
                            </div>
                        </li>
                        <!-- ... -->
                    </ul>
                </div>
                <!-- ... -->
            </div>
            <!-- ... -->
        </div>
        <!-- ... -->
    </li>
    <!-- ... -->
    <li class="header-element dropdown">
        <!-- ... -->
        <a href="javascript:void(0);" class="header-link dropdown-toggle" id="mainHeaderProfile"
            data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false">
            <div class="d-flex align-items-center">
                <div class="me-xl-2 me-0">
                    <img src="{{ asset('assets/images/faces/2.jpg') }}" alt="img" class="avatar avatar-sm avatar-rounded">
                </div>
                <div class="d-xl-block d-none lh-1">
                    <span class="fw-medium lh-1">Mr. Jack</span>
                </div>
            </div>
        </a>
        <!-- ... -->
    </li>
    <!-- ... -->
</ul>
