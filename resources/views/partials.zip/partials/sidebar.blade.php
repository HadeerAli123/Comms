   <aside class="app-sidebar sticky" id="sidebar">
<style>
.header-logo img {
  max-height: 85px !important;
  max-width: 180 !important;
  display: block !important;
  margin: 0 auto !important;
  object-fit: contain   !important;
}
.app-sidebar .main-sidebar-header .header-logo img {
    height: 9.5rem !important;;
}
.side-menu__icon {
  color: #007bff !important;
  transition: color 0.3s ease-in-out;
}

.slide:nth-child(2) .side-menu__icon { color: #ff00ea !important; }
.slide:nth-child(3) .side-menu__icon { color: #fd7e14 !important; }
.slide:nth-child(4) .side-menu__icon { color: #ffc107 !important; }
.slide:nth-child(5) .side-menu__icon { color: #20c997 !important; }
.slide:nth-child(6) .side-menu__icon { color: #9bc1427c !important; }
.side-menu__label,.breadcrumb-item{
        font-size: 1.1rem !important;
    font-weight: 500 !important;
    color: black !important;
}

</style>
            <!-- Start::main-sidebar-header -->
            <div class="main-sidebar-header">
                <a href="index.html" class="header-logo">
                    <img src="{{ asset('assets/images/new-logos/logo.png') }}" alt="logo" class="desktop-logo">

              </a>
            </div>
            <!-- End::main-sidebar-header -->

            <!-- Start::main-sidebar -->
            <div class="main-sidebar" id="sidebar-scroll">

                <!-- Start::nav -->
                <nav class="main-menu-container nav nav-pills flex-column sub-open">
                    <div class="slide-left" id="slide-left">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="#7b8191" width="24" height="24" viewBox="0 0 24 24"> <path d="M13.293 6.293 7.586 12l5.707 5.707 1.414-1.414L10.414 12l4.293-4.293z"></path> </svg>
                    </div>
                    <ul class="main-menu">


                        <!-- Start::slide -->
                        <li class="slide">
                            <a href="{{ route('dashboard') }}" class="side-menu__item">
                                <i class="bi bi-house side-menu__icon"></i>
                                <span class="side-menu__label">الرئيسية</span>
                            </a>
                        </li>
                        <li class="slide">
                            <a href="{{ route('sites.index') }}" class="side-menu__item">
                                <i class="bi bi-geo-alt side-menu__icon"></i>
                                <span class="side-menu__label">مواقع التسويق</span>
                            </a>
                        </li>
                        <li class="slide">
                            <a href="{{ route('marketers.index') }}" class="side-menu__item">
                                <i class="bi bi-person-plus side-menu__icon"></i>
                                <span class="side-menu__label">المسوقين</span>
                            </a>
                        </li>
                        <li class="slide">
                            <a href="{{ route('commissions.index') }}" class="side-menu__item">
                                <i class="bi bi-calculator side-menu__icon"></i>
                                <span class="side-menu__label">عمولات المسوقين</span>
                            </a>
                        </li>
                        <li class="slide">
                            <a href="{{ route('marketing-employees.index') }}" class="side-menu__item">
                                <i class="bi bi-people side-menu__icon"></i>
                                <span class="side-menu__label">موظفين التسويق</span>
                            </a>
                        </li>
                        <li class="slide">
                            <a href="{{ route('main-statement.index') }}" class="side-menu__item">
                                <i class="bi bi-file-earmark-text side-menu__icon"></i>
                                <span class="side-menu__label">كشف حساب رئيسي</span>
                            </a>
                        </li>   </ul>
                    <div class="slide-right" id="slide-right"><svg xmlns="http://www.w3.org/2000/svg" fill="#7b8191" width="24" height="24" viewBox="0 0 24 24"> <path d="M10.707 17.707 16.414 12l-5.707-5.707-1.414 1.414L13.586 12l-4.293 4.293z"></path> </svg></div>
                </nav>
                <!-- End::nav -->

            </div>
            <!-- End::main-sidebar -->

        </aside>
